module inertia.styles

import graphics: Canvas
import core.view: View

class Style
{
    function normal( view: View, canvas: Canvas ) { }
    function active( view: View, canvas: Canvas ) { :normal( view, canvas ) }
}

class Shiny : Style
{
    multiple = true
    
    this( multiple = true )
    {
        :multiple = multiple
    }
    
    function normal( view: View, canvas: Canvas )
    {
        gl.glBegin( gl.GL_QUAD_STRIP )
            gl.glColor4f( 1.0, 1.0, 1.0, 1.0 )
                canvas.vertex(              0,          0 )
                canvas.vertex( view.extent[0],          0 )
            gl.glColor4f( 1.0, 1.0, 1.0, 0.4 )
                canvas.vertex(              0,         30 )
                canvas.vertex( view.extent[0],         30 )
            if (:multiple)
            {
                gl.glColor4f( 1.0, 1.0, 1.0, 0.0 )
                    canvas.vertex(              0,         75 )
                    canvas.vertex( view.extent[0],         75 )
            }
        gl.glEnd()
    }
}

class Dark : Style
{
    function normal( view: View, canvas: Canvas )
    {
        gl.glBegin( gl.GL_QUAD_STRIP )
            gl.glColor4f( 1.0, 1.0, 1.0, 0.0 )
                canvas.vertex(              0,          0 )
                canvas.vertex( view.extent[0],          0 )
            gl.glColor4f( 1.0, 1.0, 1.0, 0.4 )
            //gl.glColor4f( 0.0, 0.0, 0.0, 0.3 )
                canvas.vertex(              0,         25 )
                canvas.vertex( view.extent[0],         25 )
        gl.glEnd()
    }
}

class Glossy : Style
{
/*    color1 = Vector.fromArray( "f32", [1.0, 1.0, 1.0, 0.5] )
    color2 = Vector.fromArray( "f32", [1.0, 1.0, 1.0, 0.1] )
    color3 = Vector.fromArray( "f32", [0.0, 0.0, 0.0, 0.01] )
    color4 = Vector.fromArray( "f32", [0.0, 0.0, 0.0, 0.0] )
    color5 = Vector.fromArray( "f32", [1.0, 1.0, 1.0, 0.5] )
*/
    color1 = Vector.fromArray( "f32", [1.0, 1.0, 1.0, 0.5] )
    color2 = Vector.fromArray( "f32", [1.0, 1.0, 1.0, 0.1] )
    color3 = Vector.fromArray( "f32", [0.0, 0.0, 0.0, 0.01] )
    color4 = Vector.fromArray( "f32", [0.0, 0.0, 0.0, 0.0] )
    color5 = Vector.fromArray( "f32", [1.0, 1.0, 1.0, 0.3] )

    function normal( view: View, canvas: Canvas )
    {
        gl.glBegin( gl.GL_QUADS )
            gl.glColor4fv( :color1 )
                canvas.vertex(              0,                  0 )
                canvas.vertex( view.extent[0],                  0 )
            gl.glColor4fv( :color2 )
                canvas.vertex( view.extent[0], view.extent[1] / 2.0 )
                canvas.vertex(              0, view.extent[1] / 2.0 )

            gl.glColor4fv( :color3 )
                canvas.vertex(              0, view.extent[1] / 2.0 )
                canvas.vertex( view.extent[0], view.extent[1] / 2 )
            gl.glColor4fv( :color4 )
                canvas.vertex( view.extent[0],     view.extent[1] )
                canvas.vertex(              0,     view.extent[1] )

            gl.glColor4fv( :color4 )
                gl.glVertex2f(              0, view.extent[1] / 2.0 )
                gl.glVertex2f( view.extent[0], view.extent[1] / 2.0 )
            gl.glColor4fv( :color5 )
                gl.glVertex2f( view.extent[0],     view.extent[1] )
                gl.glVertex2f(              0,     view.extent[1] )
        gl.glEnd()
    }
}

class Shaddow : Style
{
    distance = 10.0
    color1   = Vector.fromArray( "f32", [0.0, 0.0, 0.0, 0.1] )
    color2   = Vector.fromArray( "f32", [0.0, 0.0, 0.0, 0.0] )
    
    function normal( view: View, canvas: Canvas )
    {
        gl.glBegin( gl.GL_QUAD_STRIP )
            gl.glColor4fv( :color1 );  gl.glVertex2f(              0, 0                          )
            gl.glColor4fv( :color2 );  gl.glVertex2f(              0, -:distance                 )
            gl.glColor4fv( :color1 );  gl.glVertex2f( view.extent[0], 0                          )
            gl.glColor4fv( :color2 );  gl.glVertex2f( view.extent[0], -:distance                 )

            gl.glColor4fv( :color1 );  gl.glVertex2f( view.extent[0],                          0 )
            gl.glColor4fv( :color2 );  gl.glVertex2f( view.extent[0] + :distance,              0 )
            gl.glColor4fv( :color1 );  gl.glVertex2f( view.extent[0],             view.extent[1] )
            gl.glColor4fv( :color2 );  gl.glVertex2f( view.extent[0] + :distance, view.extent[1] )

            gl.glColor4fv( :color1 );  gl.glVertex2f( view.extent[0], view.extent[1]             )
            gl.glColor4fv( :color2 );  gl.glVertex2f( view.extent[0], view.extent[1] + :distance )
            gl.glColor4fv( :color1 );  gl.glVertex2f(              0, view.extent[1]             )
            gl.glColor4fv( :color2 );  gl.glVertex2f(              0, view.extent[1] + :distance )

            gl.glColor4fv( :color1 );  gl.glVertex2f(              0, view.extent[1]             )
            gl.glColor4fv( :color2 );  gl.glVertex2f(     -:distance, view.extent[1]             )
            gl.glColor4fv( :color1 );  gl.glVertex2f(              0, 0                          )
            gl.glColor4fv( :color2 );  gl.glVertex2f(     -:distance, 0                          )

            gl.glColor4fv( :color1 );  gl.glVertex2f(              0, 0                          )
            gl.glColor4fv( :color2 );  gl.glVertex2f(              0, -:distance                 )
        gl.glEnd()
    }
}

class Bevel : Style
{
    function normal( view: View, canvas: Canvas )
    {
        canvas.begin( gl.GL_LINE_LOOP )
            canvas.colorAlpha( 1.0, 1.0, 1.0, 0.3 )
                canvas.vertex( 0.5, view.extent[1] - 0.5 )
                canvas.vertex( 0.5, 0.5 );
                canvas.vertex( view.extent[0] - 0.5, 0.5 )
            canvas.colorAlpha( 0.0, 0.0, 0.0, 0.1 )
                canvas.vertex( view.extent[0] - 0.5, 0.5 )
                canvas.vertex( view.extent[0] - 0.5, view.extent[1] - 0.5 )
                canvas.vertex( 0.5, view.extent[1] - 0.5 )
        canvas.end()
    }

    function active( view: View, canvas: Canvas )
    {
        canvas.begin( gl.GL_LINES )
            canvas.colorAlpha( 0.0, 0.0, 0.0, 0.2 )
                canvas.vertex( 0.5, view.extent[1] - 0.5 )
                canvas.vertex( 0.5, 0.5 );
                canvas.vertex( 0.5, 0.5 );
                canvas.vertex( view.extent[0] - 0.5, 0.5 )
            //canvas.color( 1.0, 1.0, 1.0, 0.2 )
            //    canvas.vertex( view.extent[0] - 0.5, 0.5 )
            //    canvas.vertex( view.extent[0] - 0.5, view.extent[1] - 0.5 )
            //    canvas.vertex( 0.5, view.extent[1] - 0.5 )
        canvas.end()
        
        canvas.colorAlpha( 0.0, 0.0, 0.0, 0.1 )
        canvas.drawSolidRect( [0, 0], view.extent )
    }
}

class ThickBorder : Style
{
    function normal( view: View, canvas: Canvas )
    {
        gl.glColor3f( 0.35, 0.35, 0.35 )

        gl.glLineWidth( 2.0 )
        gl.glBegin( gl.GL_LINE_LOOP )
            canvas.vertex(                  1.0,                 -1.0 )
            canvas.vertex( view.extent[0] - 1.0,                 -1.0 )

            canvas.vertex( view.extent[0] + 1.0,                  1.0 )
            canvas.vertex( view.extent[0] + 1.0, view.extent[1] - 1.0 )

            canvas.vertex( view.extent[0] - 1.0, view.extent[1] + 1.0 )
            canvas.vertex(                  1.0, view.extent[1] + 1.0 )

            canvas.vertex(                 -1.0, view.extent[1] - 1.0 )
            canvas.vertex(                 -1.0,                  1.0 )
        gl.glEnd()
        gl.glLineWidth( 1.0 )
    }
}

class ThinBorder : Style
{
    function normal( view: View, canvas: Canvas )
    {
        gl.glColor3fv( view.border )

        canvas.drawLineRect( canvas.zero, view.extent )
    }
}

class DefaultTheme
{
    Shiny = Shiny
    Glossy = Glossy
    Shaddow = Shaddow
    Bevel = Bevel
    ThickBorder = ThickBorder
}

