module inertia.core.core

import core.view: View
import views.opengl: Scene3D
import views.button: Button, MenuButton, MenuPane
import views.window: Window
import graphics: Canvas
import styles

//loadString( io.readFile( "views/filelist.md" ) )()

class Screen : View
{
    grabbed = null
    mode    = "normal"
    mouse   = null
    menu    = MenuPane().exec $ \
    {
        :addItem( MenuButton( "Desktop Properties" ) )
        :addItem( MenuButton( "Open New Window" ) )
        :addItem( MenuButton( "Exit Inertia" ) )
        :addItem( Scene3D() )
    }
    
    function sendEvent( event: events.Event )
    {
        local view = :grabbed

        if (:grabbed)
            :grabbed.handleEvent( events.MouseEvent( event.type,
             event.point - :grabbed.absoluteOrigin(), event.button ) )
        else
            view = super.sendEvent( event )

        if (event.type == "mouseDown" && event.button == 1)
            :grabbed = view
        else
        if (event.type == "mouseUp" && event.button == 1)
            :grabbed = null

        return view
    }

    function mouseDown( point: Vector, button: int )
    {
        super.mouseDown( point, button )

        :mouse = point

        if (button == 1)
        {
            :mode = "splitter"
            
            :moveX = :children.filter( \i, child -> !!(child as Window) &&
                     point[1] > child.top() - 10 && point[1] < child.bottom() + 10 &&
                     point[0] < child.left() && point[0] > child.left() - 10 )

            :moveY = :children.filter( \i, child -> !!(child as Window) &&
                     point[0] > child.left() - 10 && point[0] < child.right() + 10 &&
                     point[1] < child.top() && point[1] > child.top() - 10 )

            :sizeX = :children.filter( \i, child -> !!(child as Window) &&
                     point[1] > child.top() - 10 && point[1] < child.bottom() + 10 &&
                     point[0] > child.right() && point[0] < child.right() + 10 )

            :sizeY = :children.filter( \i, child ->
                     point[0] > child.left() - 10 && point[0] < child.right() + 10 &&
                     point[1] > child.bottom() && point[1] < child.bottom() + 10 )

            :moveX.each $ \i, child { child.sizing = true }
            :moveY.each $ \i, child { child.sizing = true }
            :sizeX.each $ \i, child { child.sizing = true }
            :sizeY.each $ \i, child { child.sizing = true }
        }
        if (button == 3)
        {        
            :removeChild( :menu )
            
            :addChild ( :menu ).exec $ \
            {
                :origin = point + Vector.fromArray( "i16", [-10, 10] )
            }
        }
        else :removeChild( :menu )
    }
    
    function mouseMove( point: Vector, button )
    {
        local delta = point - :mouse

        if (:mode == "splitter")
        {
            foreach (child; :moveX)
            {
                child.origin[0] += delta[0]
                child.setExtent( Vector.fromArray( "i16", [child.width() - delta[0], child.height()] ) )
            }

            foreach (child; :moveY)
            {
                child.origin[1] += delta[1]
                child.setExtent( Vector.fromArray( "i16", [child.width(), child.height() - delta[1]] ) )
            }

            foreach (child; :sizeX)
            {
                child.setExtent( Vector.fromArray( "i16", [child.width() + delta[0], child.height()] ) )
            }

            foreach (child; :sizeY)
            {
                child.setExtent( Vector.fromArray( "i16", [child.width(), child.height() + delta[1]] ) )
            }

            :mouse = point
        }
    }

    function mouseUp( point: Vector, button: int )
    {
        local delta = point - :mouse

        if (:mode == "splitter")
        {
            :mode = "normal"

            foreach (child; :moveX)
            {
                child.origin[0] = (child.origin[0] + delta[0] + 5) / 10 * 10
                child.setExtent( Vector.fromArray( "i16", [(child.width() - delta[0] + 5) / 10 * 10, child.height()] ) )
            }

            foreach (child; :moveY)
            {
                child.origin[1] = (child.origin[1] + delta[1] + 5) / 10 * 10
                child.setExtent( Vector.fromArray( "i16", [child.width(), (child.height() - delta[1] + 5) / 10 * 10] ) )
            }

            foreach (child; :sizeX)
            {
                child.setExtent( Vector.fromArray( "i16", [(child.width() + delta[0] + 5) / 10 * 10, child.height()] ) )
            }

            foreach (child; :sizeY)
            {
                child.setExtent( Vector.fromArray( "i16", [child.width(), (child.height() + delta[1] + 5) / 10 * 10] ) )
            }

            :moveX.each $ \i, child { child.sizing, child.isdirty = false, true }
            :moveY.each $ \i, child { child.sizing, child.isdirty = false, true }
            :sizeX.each $ \i, child { child.sizing, child.isdirty = false, true }
            :sizeY.each $ \i, child { child.sizing, child.isdirty = false, true }
            
            //:moveX = :moveY = null
            :moveX, :moveY, :sizeX, :sizeY = null, null, null, null
        }
    }
}

// mencoder red-planet-300-9800.m2v -oac pcm -ovc raw -vf format=rgb24 -of rawvideo -o sample.raw
// mencoder red-planet-300-9800.m2v -oac pcm -ovc raw -vf format=rgb24 -of rawaudio -o sample.wav

class Video : View
{
    elapsed = 0
    bytes   = 0
    
    //function init( width: int = 720, height: int = 480 )
    function init( width: int = 380, height: int = 480 )
    {
        :frame = Vector( "u8", width * height * 3 )
        //:buffer = Vector( "u8", 256 )
        :width = width
        :height = height

        :video = os.Process()
        //:audio = os.Process()
        :video.execute( ["/usr/bin/mencoder", "videos/sample.mp4", "-msglevel", "all=-1", "-quiet" "-nosound", "-ovc", "raw", "-vf", "format=rgb24", "-of", "rawvideo", "-o", "-"] )
        //:audio.execute( ["/usr/bin/mencoder", "sample.mp4", "-msglevel", "all=-1", "-oac", "pcm", "-ovc", "raw", "-vf", "format=rgb24", "-of", "rawaudio", "-o", "-"] )

        :stream = :video.stdout()
        :stream.readln(); :stream.readln(); :stream.readln(); :stream.readln()

        //:stream = io.inFile( "sample.raw" )
        //:stream = io.outFile( "/dev/audio" )
        :count = 0
    }
    
    function drawContent( canvas: Canvas, delta: int )
    {
        :parent.backed = false

        try
        {
            :elapsed += delta
            
            if (:elapsed > 30000)
            {
                :elapsed = 0
                //:stream.rawRead( #:frame, :frame ) // crashes
                :stream.readVector( :frame )

                //:audio.stdout().readVector( :buffer )
                //:stream.write( :buffer )
            }
            
            gl.glPixelZoom( :extent[0] / 380.0, :extent[0] / -380.0 )
            gl.glRasterPos2i( 0, 0 )
            gl.glPixelStorei( gl.GL_UNPACK_ROW_LENGTH, :width )
            gl.glDrawPixels( :width, :height, gl.GL_RGB, gl.GL_UNSIGNED_BYTE, :frame )

            :count += 1
        }
        catch (error)
        {
            :video.wait()
            :video.execute( ["/usr/bin/mencoder", "videos/sample.mp4", "-msglevel", "all=-1", "-quiet" "-nosound", "-ovc", "raw", "-vf", "format=rgb24", "-of", "rawvideo", "-o", "-"] )
            :stream = :video.stdout()
            :stream.readln(); :stream.readln(); :stream.readln(); :stream.readln()
        }
    }
}

