module inertia.views.filelist

import graphics: Canvas, Color, FileModel
import core.view: View
import views.button: Button, MenuButton, ToggleButton
import views.slider: ScrollBar

class FilesView : View
{
    content = Color.White.color
    selectedIndex = -1
    rowHeight = 20
    scrollTop = 0

    function init( model: FileModel )
    {
        :model = model
    }

    function drawOverlay( canvas: Canvas, delta: int )
    {
        canvas.translate( 0, -:scrollTop + :scrollTop / 20 * 20, 0 )

        if (:selectedIndex != -1)
        {
            canvas.color( 0.65, 0.75, 0.85 )
            canvas.drawSolidRect( [0, :selectedIndex * 20 - :scrollTop / 20 * 20], [:width(), :rowHeight] )
        }

        canvas.color( 0.0, 0.0, 0.0 )

        local maxSize = math.min( :scrollTop + :height() + 20, #:model.data * 20 )

        foreach (i, file; :model.data[:scrollTop / 20..maxSize / 20])
        {
            canvas.pushMatrix()
                canvas.translate( 10, 2, 0 )
                canvas.drawString( file.name )

                canvas.translate( 300, 0, 0 )
                canvas.drawString( file.modified )

                canvas.translate( -16 - (#file.size * 8), 0, 0 )
                canvas.drawString( file.size )
            canvas.popMatrix()

            canvas.translate( 0, :rowHeight, 0 )
        }
    }

    function mouseDown( point: Vector, button: int )
    {
        if (button == 1)
        {
            :selectedIndex = (point[1] + :scrollTop) / :rowHeight
        
            :invalidate()
        }
        else if (button == 4)
        {
            :scrollTop = math.max( :scrollTop - 100, 0 )
        }
        else if (button == 5)
        {
            :scrollTop = math.min( :scrollTop + 100, #:model.data * 20 - :height() )
        }
    }
    
    function keyDown( keysym: int, modifiers: int )
    {
        if (keysym == 273) :selectedIndex -= 1
        if (keysym == 274) :selectedIndex += 1
        
        :invalidate()
    }
}

class FileList : View
{
    function init()
    {
        :model = FileModel()
        :styles.append( styles.ThinBorder )
        
        local filelist = this

        :filesview = :addChild( FilesView( :model ), [ 0, 25], [400, 174] ).exec $ \
        {
            :reshape = ["size", "size"]
        }

        :addChild( ToggleButton( "Name" ), [0, 0], [200, 25] )
        :addChild( ToggleButton( "Size" ), [200, 0], [100, 25] )
        :addChild( ToggleButton( "Modified" ), [300, 0], [200, 25] )

        :scrollBar = :addChild( ScrollBar(), [400 - 23, 25], [18, 174] ).exec $ \
        {
            :reshape = ["move", "size"]
            :onDrag  = events.Action( filelist, "scroll" )
        }
    }

    function scroll( percent )
    {
        :filesview.scrollTop = toInt( (#:model.data * 20 - :filesview.height()) * percent )
    }
}

class FileExplorer : View
{
    files = null
    
    function init()
    {
        local explorer = this

        :addChild( Button( "Back" ), [10, 10] )
        :addChild( Button( "Up" ), [65, 10] )

        :fileList = :addChild( FileList(), [0, 45] ).exec $ \
        {
            :extent  = Vector.fromArray( "i16", [400, 199] )
            :reshape = ["size", "size"]
        }

        :files = StringBuffer( toString( #:fileList.model.data ) ~ " files" )

        :status = :addChild( View(), [0, 300 - 55] ).exec $ \
        {
            :extent  = Vector.fromArray( "i16", [400, 25] )
            :reshape = ["size", "move"]
            :styles.append( styles.Dark, styles.Bevel )
            
            :drawOverlay = function( canvas: Canvas )
            {
                canvas.translate( 10, 4, 0 )
                canvas.drawString( explorer.files )
            }
        }
    }
    
    function drawContent() { }
}

