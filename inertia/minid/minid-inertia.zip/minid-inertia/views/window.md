module inertia.views.window

import config
import graphics: Canvas
import core.view: View
import views.button: Button
import events
import styles

class Client : View
{
    function drawContent( canvas: Canvas ) { }
    function drawBorder( canvas: Canvas ) { }
}

// ---------------------------------------------------------------------------------------------- //

class CloseButton : Button
{
    function drawContent( canvas: Canvas, delta: int )
    {
        if (:state == "active") super.drawContent( canvas, delta )
    }

    function drawOverlay( canvas: Canvas, delta: int )
    {
        super.drawOverlay( canvas, delta )
        
        gl.glColor3f( 0.35, 0.35, 0.35 )

        gl.glLineWidth( 2.0 )
        canvas.begin( gl.GL_LINES )
            canvas.vertex( 3, 3 )
            canvas.vertex( :width() - 3, :height() - 3 )
            canvas.vertex( :width() - 3, 3 )
            canvas.vertex( 3, :height() - 3 )
        canvas.end()
        gl.glLineWidth( 1.0 )
    }

    function drawStyles( canvas: Canvas, delta: int )
    {
        if (:state == "active") super.drawStyles( canvas, delta )
    }
    
    function drawBorder( canvas: Canvas, delta: int )
    {
        if (:state == "active") super.drawBorder( canvas, delta )
    }
}

// ---------------------------------------------------------------------------------------------- //

class MaxButton : Button
{
    function drawContent( canvas: Canvas, delta: int )
    {
        if (:state == "active") super.drawContent( canvas, delta )
    }

    function drawOverlay( canvas: Canvas, delta: int )
    {
        super.drawOverlay( canvas, delta )
        
        gl.glColor3f( 0.35, 0.35, 0.35 )

        gl.glLineWidth( 2.0 )
        canvas.begin( gl.GL_LINE_LOOP )
            canvas.vertex( 3, 3 )
            canvas.vertex( :width() - 3, 3 )
            canvas.vertex( :width() - 3, :height() - 3 )
            canvas.vertex( 3, :height() - 3 )
        canvas.end()
        gl.glLineWidth( 1.0 )
    }

    function drawStyles( canvas: Canvas, delta: int )
    {
        if (:state == "active") super.drawStyles( canvas, delta )
    }
    
    function drawBorder( canvas: Canvas, delta: int )
    {
        if (:state == "active") super.drawBorder( canvas, delta )
    }
}

// ---------------------------------------------------------------------------------------------- //

class TitleBar : View
{
    title = null
    //backgr = graphics.loadRGB( "images/titlebar.rgb" )
    backgr2 = graphics.loadRGB( "images/titlebar2.rgb" )

    function init()
    {
        local titlebar = this
        
        //:styles.append( styles.Shiny )
        :reshape = ["size", ""]
        
        :color1 = Vector.fromArray( "f32", [0.6, 0.6, 0.6] )
        :cover  = :addChild $ View().exec $ \
        {
            :styles.append( styles.Shiny( false ) )
            :reshape = ["move", ""]
            :drawBorder = function() { }

            //:handleEvent = function( event: events.Event ) { return titlebar.handleEvent( event ) }
            :mouseDown = function( origin: Vector, button: int ) { titlebar.mouseDown( origin, button ) }
            :mouseMove = function( origin: Vector, button: int ) { titlebar.mouseMove( origin, button ) }
            :mouseUp   = function( origin: Vector, button: int ) { titlebar.mouseUp( origin, button ) }

            :drawOverlay = function( canvas: Canvas, delta: int )
            {
                local width = canvas.stringWidth( :parent.title )

                canvas.translate( (:width() / 2) - (width / 2), 7, 0, 0 )
                canvas.drawString( :parent.title )
            }
        }
    }

    function sizeChange( extent: Vector )
    {
        local width = Canvas.stringWidth( :title )
        local left = (extent[0] / 2) - (width / 2)
        
        :cover.setOrigin( Vector.fromArray( "i16", [left - 10, 0] ) )
        :cover.setExtent( Vector.fromArray( "i16", [width + 20, :height()] ) )
    }
    
    function setTitle( title: string )
    {
        :title = StringBuffer( title )

        local width = Canvas.stringWidth( :title )
        local left = (:width() / 2) - (width / 2)
        
        :cover.setOrigin( Vector.fromArray( "i16", [left - 10, 0] ) )
        :cover.setExtent( Vector.fromArray( "i16", [width + 20, :height()] ) )
    }

    function drawContent( canvas: Canvas, delta: int ) { }

    function drawOverlay( canvas: Canvas, delta: int )
    {
        if (:parent.parent.focused is :parent)
        {
            gl.glPixelStorei( gl.GL_UNPACK_ROW_LENGTH, 2000 )
            gl.glPixelZoom( 1, -1 )

            canvas.rasterPos( 28, 3 )
            canvas.drawImage( :backgr2, (:width() - 28 * 2), 23 )
        }
    }
    
    function drawBorder( canvas: Canvas, delta: int )
    {
        canvas.color( 0.5, 0.5, 0.5 )
        canvas.drawLine( [0, :height() + 0], [:width(), :height() + 0] )
        //canvas.color( 0.875, 0.875, 0.875, 1.0 )
        canvas.color( 1.0, 1.0, 1.0 )
        canvas.drawLine( [0, :height() + 1], [:width(), :height() + 1] )
    }
    
    function mouseDown( point: Vector, button: int )
    {
        super.mouseDown( point, button )

        :state = "active"
        :mouse  = point
    }

    function mouseMove( point: Vector, button: int )
    {
        super.mouseMove( point, button )

        if (:state == "active")
        {
            :parent.origin += point - :mouse
            
            foreach (attach; :parent.attached)
            {
                attach.origin += point - :mouse
            }
        }
    }

    function mouseUp( point: Vector, button: int )
    {
        super.mouseUp( point, button )

        if (:state == "active")
            :parent.setOrigin( (:parent.origin + (point - :mouse) + 5) / 10 * 10 )

        :state = "normal"
    }
}

// ---------------------------------------------------------------------------------------------- //

class Sizer : View
{
    backgr = graphics.loadRGB( "images/sizerbox.rgb" )

    function init()
    {
        :reshape = ["move", "move"]
    }

    function drawContent( canvas: Canvas, delta: int )
    {
        gl.glPixelStorei( gl.GL_UNPACK_ROW_LENGTH, 25 )
        gl.glPixelZoom( 1, -1 )

        gl.glRasterPos2i( 5, 5 )
        canvas.drawImage( :backgr, 22, 22 )
    }
    
    function drawBorder( canvas: Canvas ) { }
    
    function mouseDown( point: Vector, button: int )
    {
        super.mouseDown( point, button )

        :state  = "active"
        :mouse  = point

        :parent.sizing  = true
    }

    function mouseMove( point: Vector, button: int )
    {
        super.mouseMove( point, button )

        if (:state == "active") :parent.setExtent( :parent.extent + (point - :mouse) )
    }

    function mouseUp( point: Vector, button: int )
    {
        super.mouseUp( point, button )

        if (:state == "active")
            :parent.setExtent( (:parent.extent + (point - :mouse) + 5) / 10 * 10 )

        :state  = "normal"

        :parent.isdirty = true
        :parent.sizing  = false
    }
}

// ---------------------------------------------------------------------------------------------- //

class Window : View
{
    titlebar = null
    size     = null
    isdirty  = true
    sizing   = false
    backed   = true
    onClose  = null
    bkstore  = null
    texture  = null
    
    function init( title: string = "<Untitled>", client: View = Client() )
    {
        :origin  = Vector.fromArray( "i16", [10, 10] )
        :extent  = Vector.fromArray( "i16", [400, 300] )
        :content = Vector.fromArray( "f32", [0.75, 0.75, 0.75] )

        :styles.append( styles.Bevel, styles.Shiny )

        local window = this

        :titlebar = :addChild $ TitleBar().exec $ \
        {
            :origin = Vector.fromArray( "i16", [0, 0] )
            :extent = Vector.fromArray( "i16", [window.width(), 30] )
            :setTitle( title )
        }

        local close = :addChild $ CloseButton().exec $ \
        {
            :origin  = Vector.fromArray( "i16", [7, 8] )
            :extent  = Vector.fromArray( "i16", [14, 14] )
            :onClick = events.Action( window, "close" )
        }
        
        local maximize = :addChild $ MaxButton().exec $ \
        {
            :origin  = Vector.fromArray( "i16", [window.width() - 7 - 14, 8] )
            :extent  = Vector.fromArray( "i16", [14, 14] )
            :reshape = ["move", ""]
            :onClick = events.Action( window, "maximize" )
        }

        :client = :addChild $ client.exec $ \
        {
            :origin  = Vector.fromArray( "i16", [0, 30] )
            :extent  = Vector.fromArray( "i16", [window.width(), window.height() - 30] )
            :coords  = :extent.dup()
            :reshape = ["size", "size"]
        }

        :sizer = :addChild $ Sizer().exec $ \
        {
            :origin  = Vector.fromArray( "i16", [window.extent[0] - 30, window.extent[1] - 30] )
            :extent  = Vector.fromArray( "i16", [30, 30] )
        }
    }

    function close()
    {
        if (:onClose) :onClose.invoke()
        
        :parent.removeChild( this )
    }

    function maximize()
    {
        local left, top = 0, 0
        local w, h = config.width, config.height

        foreach (child; :parent.children)
        {
            if ( !(child is this) && :left() > child.right() &&
                  :top() < child.bottom() && :bottom() > child.top() )
                left = math.max( left, child.right() )
                
            if (!(child is this) && :left() > child.right() &&
                  :top() < child.bottom() && :bottom() > child.top())
                left = math.max( left, child.right() )
        }

        foreach (child; :parent.children)
        {
            if (!(child is this) && :right() < child.left() &&
                  :top() < child.bottom() && :bottom() > child.top())
                w = math.min( w, child.left() )
        }

        foreach (child; :parent.children)
        {
            if (!(child is this) && :top() > child.bottom() &&
                  left < child.right() && left + (w - left) > child.left())
                top = math.max( top, child.bottom() )
        }

        foreach (child; :parent.children)
        {
            if ( !(child is this) && :bottom() < child.top() &&
                  left < child.right() && left + (w - left) > child.left() )
                h = math.min( h, child.top() )
        }

        :origin = Vector.fromArray( "i16", [left + 10, top + 10] )
        :setExtent( Vector.fromArray( "i16", [w - left - 20, h - top - 20] ) )
    }

    function setExtent( extent: Vector )
    {
        if (extent[0] < 200 || extent[1] < 100)
        {
            super.setExtent( Vector.fromArray( "i16", [math.max( extent[0], 200 ), math.max( extent[1], 100 )] ) )
        }
        else super.setExtent( extent )
    }

    function invalidate()
    {
        :isdirty = true
    }

    function drawClient( canvas: Canvas, delta: int )
    {
        styles.Shaddow.normal( this, canvas )

        if (!:isdirty && !:sizing)
        {
            gl.glBindTexture( gl.GL_TEXTURE_RECTANGLE_ARB, :texture )
            gl.glEnable( gl.GL_TEXTURE_RECTANGLE_ARB )

            canvas.colorAlpha( 1.0, 1.0, 1.0, 1.0 )
            canvas.begin( gl.GL_QUADS )
                gl.glTexCoord2i(        0, :height() ); canvas.vertex(        0,         0, 0 )
                gl.glTexCoord2i( :width(), :height() ); canvas.vertex( :width(),         0, 0 )
                gl.glTexCoord2i( :width(),         0 ); canvas.vertex( :width(), :height(), 0 )
                gl.glTexCoord2i(        0,         0 ); canvas.vertex(        0, :height(), 0 )
            canvas.end()

            gl.glDisable( gl.GL_TEXTURE_RECTANGLE_ARB )

            return
        }
        
        gl.glScissor( :origin[0], config.height - :origin[1] - :extent[1], :extent[0], :extent[1] )
        gl.glEnable( gl.GL_SCISSOR_TEST )

        super.drawClient( canvas, delta )

        gl.glDisable( gl.GL_SCISSOR_TEST )

        if (!:sizing)
        {
            local texture = Vector( "u32", 1 )
            gl.glGenTextures( 1, texture )
            :texture = texture[0]
            gl.glBindTexture( gl.GL_TEXTURE_RECTANGLE_ARB, :texture )

            gl.glReadBuffer( gl.GL_BACK )
            gl.glCopyTexImage2D( gl.GL_TEXTURE_RECTANGLE_ARB, 0, gl.GL_RGBA, :left(), config.height - :top() - :height(), :width(), :height(), 0 )
        }
        
        :isdirty = false
    }

    function drawBorder( canvas: Canvas, delta: int )
    {
        styles.ThickBorder.normal( this, canvas )
    }

    function sendEvent( event: events.Event )
    {
        if (event.type == "mouseDown")
            :bringToFront()
        
        return super.sendEvent( event )
    }
    
    function focusGained()
    {
        :invalidate()
    }
    
    function focusLost()
    {
        :invalidate()
    }
}

