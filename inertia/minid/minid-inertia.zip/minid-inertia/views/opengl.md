module inertia.views.opengl

import graphics: Canvas
import core.view: View

class OpenGL : View
{
    angle = 0.0
    
    function drawClient( canvas: Canvas, delta: int )
    {
        gl.glPushAttrib( gl.GL_ALL_ATTRIB_BITS )

        gl.glMatrixMode( gl.GL_PROJECTION )
            gl.glPushMatrix()
        gl.glMatrixMode( gl.GL_MODELVIEW )

        gl.glPushMatrix()
            gl.glViewport( :absoluteOrigin()[0], config.height - :absoluteOrigin()[1] - :height(), :width(), :height() )

            gl.glScissor( :absoluteOrigin()[0], config.height - :absoluteOrigin()[1] - :height(), :extent[0], :extent[1] )
            gl.glEnable( gl.GL_SCISSOR_TEST )

            :drawContent( canvas, delta )

            gl.glDisable( gl.GL_SCISSOR_TEST )
        gl.glPopMatrix()

        gl.glMatrixMode( gl.GL_PROJECTION )
            gl.glPopMatrix()
        gl.glMatrixMode( gl.GL_MODELVIEW )

        gl.glPopAttrib( gl.GL_TRANSFORM_BIT )
    }
}

class Scene3D : OpenGL
{
    function init()
    {
        :lightPos = Vector.fromArray( "f32", [3, 3, 3, 1] )
        :red = Vector.fromArray( "f32", [1, 0, 0, 1] )
        :blue = Vector.fromArray( "f32", [0, 0, 1, 1] )
        :white = Vector.fromArray( "f32", [1, 1, 1, 1] )
    }
    
    function drawContent( canvas: Canvas, delta: int )
    {
        gl.glMatrixMode( gl.GL_PROJECTION )
            gl.glLoadIdentity()
            gl.gluPerspective( 45, :width() / toFloat(:height()), 1.0, 100.0 )
        gl.glMatrixMode( gl.GL_MODELVIEW )

        gl.glClear( gl.GL_COLOR_BUFFER_BIT | gl.GL_DEPTH_BUFFER_BIT )

        gl.glLoadIdentity()        

        gl.glEnable( gl.GL_LIGHT0 )
        gl.glEnable( gl.GL_LIGHTING )

        gl.glTranslatef( 0, 0, -20 )
        gl.glRotatef( -45.0, 1, 0, 0 )
        gl.glRotatef( :angle, 0, 0, 1 )
        gl.glLightfv( gl.GL_LIGHT0, gl.GL_POSITION, :lightPos )
        gl.glLightfv( gl.GL_LIGHT0, gl.GL_SPECULAR, :red )

        :angle += (delta / 100000.0)
        if (:angle > 359) :angle = 0

        //gl.glColor3f( 1.0, 0.0, 0.0 )
        gl.glNormal3f( 0, 0, 1 )
        gl.glMaterialfv( gl.GL_FRONT, gl.GL_DIFFUSE, :white )
        gl.glMaterialfv( gl.GL_FRONT, gl.GL_SPECULAR, :red )
        gl.glMaterialf( gl.GL_FRONT, gl.GL_SHININESS, 15.0 )

        for (i; -5..5) for (j; -5..5)
        {
            gl.glRectf( i, j, i + 1.0, j + 1.0 )
        }

        gl.glPolygonMode( gl.GL_FRONT, gl.GL_LINE )
        gl.glRectf( -5, -5, 5, 5 )
        gl.glPolygonMode( gl.GL_FRONT, gl.GL_FILL )
        
        :invalidate()
    }
}

