module inertia.views.button

import graphics: Canvas
import core.view: View

class Button : View
{
    caption  = ""
    center   = true
    onClick  = null

    function init( caption: string = "" )
    {
        :caption = StringBuffer( caption )
        :content = Vector.fromArray( "f32", [0.875, 0.875, 0.875] )
        //:styles.append( styles.Glossy, styles.Bevel )
        :styles.append( styles.Glossy, styles.Bevel, styles.ThinBorder )
        
        :minsize = Vector.fromArray( "i16", [Canvas.stringWidth( :caption ) + 16, 25] )
        :extent  = :minsize.dup()
    }

    function drawOverlay( canvas: Canvas, delta: int )
    {
        local width  = canvas.stringWidth( :caption )
        local offset = :state == "active" ? 1 : 0

        canvas.pushMatrix()
            if (:center)
                canvas.translate( (:extent[0] / 2) - (width / 2) + offset, (:extent[1] / 2 - 8) + offset, 0, 0 )
            else
                canvas.translate( 8 + offset, (:extent[1] / 2 - 8) + offset, 0, 0 )
            canvas.drawString( :caption )
        canvas.popMatrix()
    }

    function mouseDown( point: Vector, button: int )
    {
        super.mouseDown( point, button )

        if (button == 1)
        {
            :state = "active"
            :invalidate()
        }
    }

    function mouseMove( point: Vector )
    {
        if (config.screen.grabbed is this)
        {
            :state = :containsPoint( point ) ? "active" : "normal"
            :invalidate()
        }
    }

    function mouseUp( point: Vector, button: int )
    {
        super.mouseUp( point, button )

        if (:state == "active") :click()

        :state = "normal"
        :invalidate();
    }

    function click()
    {
        if (:onClick) :onClick.invoke()
    }

}

class ToggleButton : Button
{
    toggle
    
    function init( caption: string )
    {
        super.init( caption )
        
        :toggle = false
        :styles = [styles.Glossy, styles.Bevel]
    }
    
    //function drawContent() { }
    function drawBorder() { }

    function mouseDown( point: Vector, button: int )
    {
        super.mouseDown( point, button )

        if (button == 1)
        {
            :state = "active"
            :invalidate()
        }
    }

    function mouseUp( point: Vector, button: int )
    {
        super.mouseUp( point, button )

        :toggle = !:toggle
        :state = :toggle ? "active" : "normal"
        :invalidate();
    }
    
}

class MenuButton : Button
{
    function init( caption: string )
    {
        super.init( caption )
        
        :styles = [styles.Glossy, styles.Bevel]
        :center  = false        
    }
    
    //function drawContent() { }
    function drawBorder() { }
    
    function click()
    {
        super.click()

        //:parent.parent.removeChild( :parent )
    }
}

class MenuPane : View
{
    viewtop = 0
    
    function init()
    {
        :viewtop = 0
        
        :styles.append( styles.Shiny, styles.Bevel, styles.ThinBorder )
    }

    function addItem( item: View )
    {
        item.setOrigin( Vector.fromArray( "i16", [0, :viewtop] ) )
        
        :addChild( item )

        local width = 0
        
        foreach (child; :children)
        {
            width = math.max( width, child.minsize[0] )
        }

        foreach (child; :children)
        {
            child.setExtent( Vector.fromArray( "i16", [width, child.extent[1]] ) )
        }

        :viewtop += item.height() + 0
        
        :setExtent( Vector.fromArray( "i16", [width, :viewtop - 0] ) )
        
    }
    
    function drawClient( canvas: Canvas, delta: int )
    {
        styles.Shaddow.normal( this, canvas )

        super.drawClient( canvas, delta )
    }
}

