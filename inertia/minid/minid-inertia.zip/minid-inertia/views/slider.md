module inertia.views.slider

import graphics: Canvas
import core.view: View

class Thumb : View
{
    backgr2 = graphics.loadRGB( "images/titlebar2.rgb" )

    function init()
    {
        :styles.append( styles.ThinBorder, styles.Bevel )
    }
    
    function drawContent( canvas: Canvas, delta: int )
    {
        super.drawContent( canvas, delta )
        
        gl.glBegin( gl.GL_QUADS )
            gl.glColor4f( 1.0, 1.0, 1.0, 0.0 )
                canvas.vertex( :extent[0],          0 )
                canvas.vertex( :extent[0], :extent[1] )
            gl.glColor4f( 1.0, 1.0, 1.0, 0.5 )
                canvas.vertex(          0, :extent[1] )
                canvas.vertex(          0,          0 )
        gl.glEnd()
    }
    
    function drawOverlay( canvas: Canvas, delta: int )
    {
            gl.glPixelStorei( gl.GL_UNPACK_ROW_LENGTH, 2000 )
            gl.glPixelZoom( 1, -1 )

            canvas.rasterPos( 3, 3 )
            canvas.drawImage( :backgr2, 25 - 13, 25 )
    }
    
    function mouseDown( point: Vector, button: int )
    {
        if (button == 1)
        {
            :mouse = point
        }
        
        :parent.parent.parent.parent.sizing = true
    }
    
    function mouseMove( point: Vector, button: int )
    {
        local delta = point - :mouse
        
        if (button == 1)
        {
            if (delta[1] < 0) :origin[1] = math.max( :origin[1] + delta[1], 5 )
            if (delta[1] > 0) :origin[1] = math.min( :origin[1] + delta[1], :parent.height() - :height() - 5 )

            local percent = toFloat( :top() - 5 ) / toFloat( :parent.height() - :height() - 10 )

            :parent.slide( percent )
        }
        
        :invalidate()
    }
    
    function mouseUp( point: Vector, button: int )
    {
        :parent.parent.parent.parent.sizing = false
        
        :invalidate()
    }
}

class ScrollBar : View
{
    position
    range
    
    function init( position: float = 0.0, range: array = [0.0, 1.0] )
    {
        :range = range
        
        :thumb = :addChild( Thumb(), [0, 50], [18, 100] )
    }

    function slide( percent )
    {
        if (:onDrag) :onDrag.invoke( (:range[1] - :range[0]) * percent + :range[0] )
    }

    function setPosition( position: float )
    {
    }

    function setRange( range: array )
    {
        :range = range
    }
    
    function drawContent( canvas: Canvas, delta: int )
    {
        canvas.drawSolidRect( [:width() / 2 - 1, 15], [2, :height() - 30] )
    }
}

