module inertia.views.console

import graphics: Canvas, Color
import core.view: View
import styles

class Text : View
{
    buffer = null
    bkstore = null
    
    function init( text: string = "" )
    {
        :buffer = StringBuffer( text )
        :content = Color.White.color
        :styles.append( styles.ThinBorder )
        
        :bkstore = Vector( "u8" )
    }

    function drawOverlay( canvas: Canvas )
    {
        local tail = :buffer
        local width = 0

        canvas.translate( 10, 2, 0 )

        while (#tail != 0)
        {
            width = math.min( #tail, (:width() - 20) / 8 )

            local str = tail[..width]
            
            if (width == (:width() - 20) / 8)
            {
                local i = str.rfind( ' ', -1 )
                if (i != #str) width = i + 1
            }
            
            local i = str.find( '\n' )
            if (i != #str) width = i + 1

            canvas.drawString( StringBuffer( tail[..width] ) )

            if (#tail == width)
                tail = ""
            else
                tail  = tail[width..]

            canvas.translate( 0, 20, 0 )
        }        
    }
}

class Input : View
{
    buffer  = null
    onEnter = null
    
    function init()
    {
        :buffer = StringBuffer()
        :content = Color.White.color
        :styles.append( styles.ThinBorder )
    }
    
    function drawContent( canvas: Canvas, delta: int )
    {
        super.drawContent( canvas, delta )
        
        if (:parent.focused is this)
        {
            canvas.color( 1.0, 0.9, 0.5 )
            canvas.drawSolidRect( [0, 0], [:width(), :height()] )
        }
    }
    
    function drawOverlay( canvas: Canvas, delta: int )
    {
        canvas.translate( 10, 4, 0 )
        canvas.drawString( :buffer )
    }
    
    function keyDown( keysym: int, modifiers: int, char )
    {
        super.keyDown( keysym, modifiers, char )

        switch (keysym)
        {
            case  8: if (#:buffer > 0) :buffer.remove( -1 ); break
            case 13: if (:onEnter) :onEnter.invoke(); break
            default: if (keysym < 128) :buffer.append( char ); break
        }
        
        :invalidate()
    }
    
    function mouseDown( point: Vector, button: int )
    {
        :invalidate()
    }
}

class Console : View
{
    function init()
    {
        local text = "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod " ~
                     "tempor incididunt ut labore et dolore magna aliqua.Ut enim ad minim veniam, " ~
                     "quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo " ~
                     "consequat.\nDuis aute irure dolor in reprehenderit in voluptate velit esse " ~
                     "cillum dolore eu fugiat nulla pariatur.  Excepteur sint occaecat cupidatat " ~
                     "non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\n"

        local console = this

        :history = :addChild( Text( text ), [0, 0], [400, 244] ).exec $ \
        {
            :reshape = ["size", "size"]
        }
        
        :input = :addChild( Input(), [0, 245], [400, 25] ).exec $ \
        {
            :reshape = ["size", "move"]
            :onEnter = events.Action( console, "evaluate", :buffer )
        }

        :input.buffer.append( ">>> " )
    }
    
    function evaluate( code )
    {
        code = code[4..]

        :history.buffer.append( ">>> " ~ toString( code ) ~ "\n" )
        
        try
        {
            local result = loadString( code )()

            :history.buffer.append( " => " ~ toString( result ) ~ "\n" )
        }
        catch( error )
        {
            try
            {
                local result = eval( code )

                :history.buffer.append( " => " ~ toString( result ) ~ "\n" )
            }
            catch( error2 )
            {
                :history.buffer.append( "Error: " ~ error2 ~ "\n" )
            }
        }

        #:input.buffer = 0
        :input.buffer.append( ">>> " )
    }
}

class IRC : View
{
    socket = null
    
    function xinit()
    {
        :socket = net.connect( "irc.freenode.net", 8001 )
        :socket.setTimeout( 0.01 )

        :socket.write( "user maustin3 0 0 :Mike Austin\r\n" )
        :socket.write( "nick maustin3\r\n" )
        :socket.write( "join #d.minid\r\n" )

        local irc = this
        
        :history = :addChild( Text( "test\n" ), [0, 0], [400, 244] ).exec $ \
        {
            :reshape = ["size", "size"]
        }
        
        :input = :addChild( Input(), [0, 245], [400, 25] ).exec $ \
        {
            :reshape = ["size", "move"]
            :onEnter = events.Action( irc, "send", :buffer )
        }
    }

    function send( str )
    {
        :socket.write( "privmsg #d.minid :" ~ :input.buffer.toString() ~ "\r\n" )

        #:input.buffer = 0
    }
    
    function drawContent( canvas: Canvas, delta: int )
    {
        try
        {
            :history.buffer.append( :socket.readln() ~ "\n" )
        }
        catch (error)
        {
        }
    }
}

