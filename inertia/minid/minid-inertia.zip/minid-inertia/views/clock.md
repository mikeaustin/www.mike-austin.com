module views.clock

import graphics: Canvas
import core.view: View

class Clock : View
{
    function drawContent( canvas: Canvas, delta: int )
    {
        local time = time.dateTime()
        local size = math.min( :width() - 20, :height() - 20 ) / 2.0
        local x, y = 0, 0
        local offset = 5
        local degrees = math.pi / 180
        
        canvas.translate( :width() / 2, :height() / 2, 0 )
        canvas.rotate( -90, 0, 0, 1 )

        gl.glLineWidth( 2.0 )
        canvas.begin( gl.GL_LINES )
            for (angle; 0..60)
            {
                x = math.cos( angle * (360/60) * (math.pi / 180) )
                y = math.sin( angle * (360/60) * (math.pi / 180) )

                if (angle % (60/12) == 0)
                {
                    canvas.color( 0.0, 0.0, 0.0 )
                    offset = 10
                }
                else
                {
                    canvas.color( 0.5, 0.5, 0.5 )
                    offset = 5
                }
                
                canvas.vertex( x * (size - offset), y * (size - offset) )
                canvas.vertex( x * (size)         , y * (size)          )
            }

            canvas.color( 0.0, 0.0, 0.0 )

            x = math.cos( (time.hour * (60/12) + (time.min / 12)) * (360/60) * (math.pi / 180) )
            y = math.sin( (time.hour * (60/12) + (time.min / 12)) * (360/60) * (math.pi / 180) )

            canvas.vertex( x * (size * -0.1), y * (size * -0.1) )
            canvas.vertex( x * (size * 0.6), y * (size * 0.6) )

            x = math.cos( time.min * (360/60) * (math.pi / 180) )
            y = math.sin( time.min * (360/60) * (math.pi / 180) )

            canvas.vertex( x * (size * -0.2), y * (size * -0.2) )
            canvas.vertex( x * (size - 15) , y * (size - 15) )
        canvas.end()
        gl.glLineWidth( 1.0 )
        
        :invalidate()
    }
}

