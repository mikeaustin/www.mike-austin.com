module inertia.shapes

import graphics: Canvas
import core.view: View
import views.button: MenuButton, MenuPane

class Easel : View
{
    function drawContent( canvas: Canvas, delta: int )
    {
        super.drawContent( canvas, delta )
        
        if (:focused)
        {
            canvas.color( 0.0, 0.0, 0.0 )
            canvas.drawLineRect( :focused.origin, :focused.origin + :focused.extent )
            
//            canvas.drawSolidRect( :focused.absoluteOrigin(), [10, 10] )
//            canvas.drawSolidRect( [:width() - 10, 0], [10, 10] )
//            canvas.drawSolidRect( [:width() - 10, :height() - 10], [10, 10] )
//            canvas.drawSolidRect( [0, :height() - 10], [10, 10] )
        }
    }

    function mouseDown( point: Vector, button: int )
    {
        if (button == 1) :focused = null
        
        :invalidate()
    }
}

class Shape : View
{
    mode     = "move"
    delegate = null

    function init( delegate: View|null )
    {
        :delegate = delegate
    }

    function draw( canvas: Canvas, delta: int )
    {
        super.draw( canvas, delta )

        if (:delegate)
            :delegate.draw( canvas, delta )
    }

    function drawOverlay( canvas: Canvas, delta: int )
    {
        if (:parent.focused is this)
        {
            canvas.color( 0.0, 0.0, 0.0 )
            canvas.drawLineRect( [0, 0], [:width(), :height()] )
            
            canvas.drawSolidRect( [0, 0], [10, 10] )
            canvas.drawSolidRect( [:width() - 10, 0], [10, 10] )
            canvas.drawSolidRect( [:width() - 10, :height() - 10], [10, 10] )
            canvas.drawSolidRect( [0, :height() - 10], [10, 10] )
        }
    }
    
    function mouseDown( point: Vector, button )
    {
        //:parent.focused = this

        if (button == 1)
        {
            :first = point
            :mouse = point

            if (point[0] < 10 && point[1] < 10)
                :mode = "sizexy"
            else if (point[0] > :width() - 10 && point[1] < 10)
                :mode = "sizexw"
            else if (point[0] > :width() - 10 && point[1] > :height() - 10)
                :mode = "sizewh"
            else if (point[0] < 10 && point[1] > :height() - 10)
                :mode = "sizexh"
            else
                :mode = "move"
                
            :parent.parent.parent.sizing = true
        }
        else if (button == 3)
        {
            //:menu.popup( point + Vector.fromArray( "i16", [-10, 10] ) )
            local origin = :absoluteOrigin()
            local shape = this

            local menu = MenuPane().exec $ \
            {
                :addItem $ MenuButton( "Bring to Front" ).exec $ \
                {
                    :onClick = events.Action( shape, "bringToFront" )
                }
                :addItem( MenuButton( "Shape Properties" ) )
            }
            
            config.screen.addChild ( menu ).exec $ \
            {
                :origin = origin + point + Vector.fromArray( "i16", [-10, 10] )
            }
        }
    }

    function mouseMove( point: Vector, button )
    {
        if (:parent.focused is this && :state != "active")
        {
            if (math.abs( point[0] - :first[0]) > 5 || math.abs( point[1] - :first[1]) > 5 )
                :state = "active"
        }
        
        if (:state == "active" && button == 1)
        {
            if (:mode == "sizexy")
            {
                :origin += point - :first
                :extent -= point - :first
            }
            else if (:mode == "sizexw")
            {
                :extent[0] += point[0] - :mouse[0]
                :origin[1] += point[1] - :first[1]
                :extent[1] -= point[1] - :first[1]
            }
            else if (:mode == "sizewh")
            {
                :extent += point - :mouse
            }
            else if (:mode == "sizexh")
            {
                :origin[0] += point[0] - :first[0]
                :extent[0] -= point[0] - :first[0]
                :extent[1] += point[1] - :mouse[1]
            }
            else if (:mode == "move")
            {
                :origin += point - :first
                
                if (:delegate)
                    :delegate.origin += point - :first
            }

            :mouse = point
        }
    }

    function mouseUp( point: Vector, button: int )
    {
        :state = "normal"
        :mode  = "move"

        :parent.parent.parent.sizing = false
        
        :invalidate()
    }
}

class Rectangle : Shape
{
    function drawContent( canvas: Canvas, delta: int )
    {
        canvas.color( 0.5, 0.75, 1.0 )
        canvas.drawSolidRect( [0, 0], [:width(), :height()] )
        canvas.color( 0.0, 0.0, 0.0 )
        canvas.drawLineRect( [0, 0], [:width(), :height()] )
    }
}

class Ellipse : Shape
{
    function drawContent( canvas: Canvas, delta: int )
    {
        local radiusx = :width() / 2.0
        local radiusy = :height() / 2.0
        local maxrad  = math.max( radiusx, radiusy )
        //local by = toInt( 1000.0 / (maxrad) + 1.0 )
        local by = math.min( toInt( math.asin( 1.0 / maxrad ) * 1000.0 ), 10 )

        canvas.color( 0.5, 0.75, 1.0 )
        canvas.begin( gl.GL_TRIANGLE_FAN )
            canvas.vertex( radiusx, radiusy )

            for (a; 0..360, by)
            {
                canvas.vertex( math.cos( a * (math.pi / 180) ) * radiusx + radiusx,
                               math.sin( a * (math.pi / 180) ) * radiusy + radiusy )
            }

            canvas.vertex( math.cos( 0 * (math.pi / 180) ) * radiusx + radiusx,
                           math.sin( 0 * (math.pi / 180) ) * radiusy + radiusy )
        canvas.end()

        canvas.color( 0.0, 0.0, 0.0 )
        canvas.begin( gl.GL_LINE_LOOP )
            for (a; 0..360, by)
            {
                canvas.vertex( math.cos( a * (math.pi / 180) ) * radiusx + radiusx,
                               math.sin( a * (math.pi / 180) ) * radiusy + radiusy )
            }
        canvas.end()
    }
}

