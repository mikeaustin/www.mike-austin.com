module inertia

import sdl
import gl
import net

import config
import styles
//global theme = styles.DefaultTheme

import core.view: View
import events

import core: Screen
import views.button: Button, MenuButton, MenuPane, ToggleButton
import views.window: Window

import views.opengl: Scene3D
import views.clock: Clock
import views.filelist: FileExplorer
import shapes
import views.console: Console, IRC

local _writeln = writeln
writeln = function( vararg )
{
    _writeln( vararg )

    io.stdout.flush()
}

//                                                                           //
// ========================================================================= //
//                                                                           //

config.screen = Screen().exec $ \
{
    :extent  = Vector.fromArray( "i16", [config.width, config.height] )
    :content = Vector.fromArray( "f32", [0.65, 0.75, 0.85] )
}

local palette = MenuPane().exec $ \
{
    :origin = Vector.fromArray( "i16", [-103, 34] )
    :extent = Vector.fromArray( "i16", [105, 70] )

    this["rect"] = ToggleButton( "X" ).exec $ \
    {
        :extent = Vector.fromArray( "i16", [35, 35] )
        :center = true
    }
    this["circle"] = ToggleButton( "O" ).exec $ \
    {
        :origin = Vector.fromArray( "i16", [35, 0] )
        :extent = Vector.fromArray( "i16", [35, 35] )
        :center = true
    }
    this["circle"] = ToggleButton( "/" ).exec $ \
    {
        :origin = Vector.fromArray( "i16", [70, 0] )
        :extent = Vector.fromArray( "i16", [35, 35] )
        :center = true
    }
    this["circle"] = ToggleButton( "=" ).exec $ \
    {
        :origin = Vector.fromArray( "i16", [0, 35] )
        :extent = Vector.fromArray( "i16", [35, 35] )
        :center = true
    }
}

//config.screen.addChild( palette )

//config.screen.addChild( View(), [0, 0], [config.screen.width(), 25] ).exec $ \
//{
//    :styles.append( styles.Shiny, styles.ThinBorder )
    
//    :addChild( MenuButton( "Inertia" ) )
//}

local window = Window( "Draw" ).exec $ \window
{
    :extent = Vector.fromArray( "i16", [400, 300] )
    :attached.append( palette )
    
    this.client["client"] = shapes.Easel().exec $ \
    {
        :extent  = Vector.fromArray( "i16", [window.width(), window.height() - 30] )
        :content = Vector.fromArray( "f32", [1.0, 1.0, 1.0] )
        :reshape = ["size", "size"]

        local button = Button( "Press Me!" ).exec $ \
        {
            //:origin  = Vector.fromArray( "i16", [150, 50] )
            :extent  = Vector.fromArray( "i16", [100, 25] )
            /// This is wrong because it creates only one Window, but just for testing
            :onClick  = events.Action ( config.screen, "addChild", Window() )
            :content = Vector.fromArray( "f32", [0.9375, 0.734375, 0.16796875] )
            //:reshape = ["size", "size"]
        }

        :addChild( shapes.Shape( button ) )        
        :addChild( shapes.Rectangle() )
        :addChild( shapes.Ellipse() )
    }
}

config.screen.addChild( Window( "Clock", Clock().exec $ \
{
    //:styles.append( styles.Glossy )
}), [500, 10] )
config.screen.addChild( window )
config.screen.addChild( Window( "OpenGL", Scene3D() ), [10, 400] )
config.screen.addChild( Window( "Files", FileExplorer() ), [500, 400] )
//if (io.exists( "/usr/bin/mencoder"))
//    config.screen.addChild( Window( "Video", core.Video() ), [800, 100], [380, 480 + 30] )
//config.screen.addChild( Window( "IRC", IRC() ), [100, 100], [640, 480] )

function initSDL()
{
    sdl.init( sdl.initEverything )

    sdl.event.enableUnicode( 1 )
    //scope( exit ) sdl.quit()

    sdl.gl.setAttribute( sdl.gl.bufferSize, 32 )
    sdl.gl.setAttribute( sdl.gl.depthSize, 16 )
    sdl.gl.setAttribute( sdl.gl.doubleBuffer, 1 )

    sdl.setCaption( "MiniD-Inertia" )
    sdl.showCursor( true )
    sdl.event.keyRepeat( 500, 10 )

    if (!sdl.setVideoMode( config.width, config.height, 32, sdl.opengl | sdl.hwSurface ))
        if (!sdl.setVideoMode( config.width, config.height, 32, sdl.opengl | sdl.swSurface ))
            throw "Could not set video mode"
}

function initGL()
{
    gl.load()

    gl.glMatrixMode( gl.GL_PROJECTION )

        gl.glLoadIdentity()
        gl.gluOrtho2D( 0, config.width, config.height, 0 )

    gl.glMatrixMode( gl.GL_MODELVIEW )

    gl.glViewport( 0, 0, config.width, config.height )
    
    //gl.glFrontFace( gl.GL_CW )
    gl.glEnable( gl.GL_LINE_SMOOTH )
    gl.glBlendFunc( gl.GL_SRC_ALPHA, gl.GL_ONE_MINUS_SRC_ALPHA )
    gl.glEnable( gl.GL_BLEND )
}

initSDL()
initGL()

local quit  = false
local mouse = Vector.fromArray( "i16", [0, 0] )
local mouseState = false
local mouseButton
local keyModifiers

sdl.event.setHandler $ sdl.event.mouseButton, \state, button
{
    mouseState  = state
    mouseButton = button
    
    if (state == true)
        config.screen.sendEvent( events.MouseEvent( "mouseDown", [mouse[0], mouse[1]], mouseButton ) )
    else
        config.screen.sendEvent( events.MouseEvent( "mouseUp", [mouse[0], mouse[1]], mouseButton ) )
}

sdl.event.setHandler $ sdl.event.mouseMotion, \x, y, xd, yd
{
    mouse[0] = x
    mouse[1] = y

    if (mouseState == true)
        config.screen.sendEvent( events.MouseEvent( "mouseMove", [mouse[0], mouse[1]], mouseButton ) )
}

sdl.event.setHandler $ sdl.event.key, \pressed, keysym, modifiers, char: char
{
    keyModifiers = modifiers

    if (keysym == 27)
        quit = true

    if (pressed)
        config.screen.sendEvent( events.KeyEvent( "keyDown", keysym, modifiers, char ) )
}

sdl.event.setHandler $ sdl.event.quit, \
{
    quit = true
}

local canvas = graphics.Canvas()

local xtime, frames, fps = time.microTime(), 0, StringBuffer( "0" )
local elapsed, delta = time.microTime(), 0

while( !quit )
{
    sdl.event.poll()
    //sdl.event.wait()

    gl.glClear( gl.GL_COLOR_BUFFER_BIT | gl.GL_DEPTH_BUFFER_BIT )

        local a = time.microTime()
        delta = a - xtime
        xtime = a

        config.screen.draw( canvas, delta )

        frames += 1
        elapsed += delta
        if (elapsed > 1000000)
        {
            elapsed = 0
            fps = StringBuffer( toString( frames ) )
            frames = 0
        }

        canvas.drawString( fps )

    sdl.gl.swapBuffers()
}

