module inertia.config

//global width  = 1024
//global height = 768

global width  = 1024
global height = 768

global screen

