module inertia.view

import config
//import events
import graphics: Canvas

//global debug = writeln
global debug = function() { }

class Frame : Object
{
    function left() = :origin[0]
    function top()  = :origin[1]
    function right() = :origin[0] + :extent[0]
    function bottom() = :origin[1] + :extent[1]
    function width() = :extent[0]
    function height() = :extent[1]

    function absoluteOrigin()
    {
        local view   = this
        local origin = :origin.dup()
        
        while (view.parent)
        {
            origin += view.parent.origin
            view = view.parent
        }
        
        return origin
    }
}

class Layer : Object
{
    function addChild( child: View, origin: array|null, extent: array|null )
    {
        child.parent = this

        :children.append( child )

        if (origin) child.origin = Vector.fromArray( "i16", origin )
        if (extent) child.setExtent( Vector.fromArray( "i16", extent ) )

        return child
    }

    function removeChild( child: View )
    {
        child.parent = null

        //:children.find( child )
        local index = :children.findIf( \item -> item is child )

        if (index != #:children)
            :children.pop( index )

        return child
    }
    
    function bringToFront()
    {
        local parent = :parent
        
        parent.removeChild( this )
        parent.addChild( this )
    }
}

class Drawing : Object
{
    function drawContent( canvas: Canvas, delta: int )
    {
        gl.glColor3fv( :content )

        gl.glRects( 0, 0, :extent[0], :extent[1] )
    }

    function drawStyles( canvas: Canvas, delta: int )
    {
        foreach (style; :styles)
        {
            style.(:state)( this, canvas, delta )
        }
    }

    function drawChildren( canvas: Canvas, delta: int )
    {
        foreach (child; :children)
        {
            child.draw( canvas, delta )
        }
    }

    function drawOverlay( canvas: Canvas, delta: int ) { }

    function drawBorder( canvas: Canvas, delta: int )
    {
        gl.glColor3fv( :border )

        //canvas.drawLineRect( canvas.zero, :extent )
    }
}

class Sizing : Object
{
    function resize( delta: Vector )
    {
        if (:reshape[0] == "move" || :reshape[1] == "move")
        {
            local origin = :origin.dup()

            if (:reshape[0] == "move") origin[0] = :origin[0] + delta[0]
            if (:reshape[1] == "move") origin[1] = :origin[1] + delta[1]

            :setOrigin( origin )
        }

        if (:reshape[0] == "size" || :reshape[1] == "size")
        {                
            local extent = :extent.dup()

            :coords += delta

            if (:reshape[0] == "size") extent[0] = math.max( :coords[0], :minsize[0] )
            if (:reshape[1] == "size") extent[1] = math.max( :coords[1], :minsize[1] )

            :setExtent( extent )
        }
    }
}

class Events : Object
{
    function mouseDown( point: Vector, button: int ) { debug( this, ":mouseDown: ", point[0], " ", point[1] ) }
    function mouseUp( point: Vector, button: int ) { debug( this, ":mouseUp: ", point[0], " ", point[1] ) }
    function mouseMove( point: Vector, button: int ) { debug( this, ":mouseMove: ", point[0], " ", point[1] ) }

    function keyDown( keysym: int, modifiers: int ) { debug( this, ":keyDown: ", keysym, " ", modifiers ) }

    function focusGained() { debug( this, ":focusGained" ) }
    function focusLost() { debug( this, ":focusLost" ) }

    function sizeChange( extent: Vector ) { debug( this, ":sizeChange: ", extent ) }
}

function mixins( clazz: class, vararg )
{
    local mixins = [vararg]

	foreach (mixin; mixins)
    {
		foreach (name, field; fieldsOf( mixin ))
			clazz.( name ) = field
    }
    
    return clazz
}

@mixins( Frame, Layer, Drawing, Sizing, Events )
class View : Object
{
    parent   = null
    children = null
    attached = null
    origin   = null
    extent   = null
    coords   = null
    fields   = null
    styles   = null
    focused  = null
    state    = "normal"
    minsize  = Vector.fromArray( "u16", [10, 10, 10] )

    //content = Vector.fromArray( "f32", [0.875, 0.875, 0.875] )
    content = Vector.fromArray( "f32", [0.75, 0.75, 0.75] )
    border  = Vector.fromArray( "f32", [0.5, 0.5, 0.5] )

    this( vararg )
    {
        :origin   = Vector.fromArray( "i16", [0, 0] )
        :extent   = Vector.fromArray( "i16", [100, 100] )
        :reshape  = ["", ""]
        :children = []
        :attached = []
        :styles   = []
        :fields   = {}

        this.init( vararg )

        :coords   = :extent.dup()
        
        :stylesf  = :styles.map $ \style -> {self = style, normal = style.normal, active = style.active}
    }

    function init() { }

    function exec( block )
    {
        block( with this, this )

        :coords = :extent.dup()
        
        return this
    }

 //
 // Reshaping
 //

    function getWidth() = :extent[0]

    function setOrigin( extent: Vector )
    {
        :origin = extent
    }

    function setExtent( extent: Vector )
    {
        local delta = extent - :extent
        
        foreach (child; :children)
        {
            child.resize( delta )
        }

        :sendEvent( events.ShapeEvent( "sizeChange", extent ) )

        :extent = extent
    }

 //
 // Fields
 //

    function opIndexAssign( index, value )
    {
        :fields[ index ] = value

        this.addChild( value )
    }

    function opIndex( index )
    {
        return :fields[ index ]
    }

 //
 // Drawing
 //

    function invalidate()
    {
        if (:parent) :parent.invalidate()
    }

    function draw( canvas: Canvas, delta: int )
    {
        canvas.pushMatrix()
            canvas.translate( :origin[0], :origin[1], 0, 0 )

            :drawClient( canvas, delta )
            :drawBorder( canvas, delta )
        canvas.popMatrix()
    }

    function drawClient( canvas: Canvas, delta: int )
    {
        canvas.pushMatrix()
            :drawContent( canvas, delta )
        canvas.popMatrix()

        :drawStyles( canvas, delta )
        :drawOverlay( canvas, delta )
        :drawChildren( canvas, delta )
    }

 //
 // Events
 //

    function sendEvent( event: events.Event )
    {
        return event.dispatchEvent( this )
    }

    function handleEvent( event: events.Event )
    {
        if (event as events.MouseEvent)
            this.(event.type)( event.point, event.button )
        else if (event as events.ShapeEvent)
            this.(event.type)( event.extent )
        else if (event as events.KeyEvent)
            this.(event.type)( event.keysym, event.modifiers, event.char )
    }

    function containsPoint( point: Vector )
    {
        return point[0] >= 0 && point[0] <= :extent[0] &&
               point[1] >= 0 && point[1] <= :extent[1]
    }
}

