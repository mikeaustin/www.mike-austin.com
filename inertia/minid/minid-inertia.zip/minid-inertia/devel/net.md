module net

local net = os.Process()
net.execute( ["/usr/bin/telnet", "www.sun.com", "80"] )

local buffer = StringBuffer( "1234567890" )
net.stdout().readVector( buffer, 10 )

writeln( toInt( buffer[1]) )

