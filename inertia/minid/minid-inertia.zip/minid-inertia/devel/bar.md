module inertia

writeln( "bar.md" )

class Bar
{
}

