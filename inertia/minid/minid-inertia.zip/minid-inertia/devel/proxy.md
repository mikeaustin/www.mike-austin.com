module test

local net = os.Process()
net.execute( ["./ircproxy", "irc.freenode.net", "8001"] )

local buffer

while (true)
{
	net.stdin().writeln( "\0" )

	buffer = net.stdout().readln()
	while (buffer != "")
	{
		writeln( buffer )
		buffer = net.stdout().readln()
	}

	writeln( "..." )
	time.sleep( 1.0 )
}

