module test

class View
{
    _getters = {}
    _setters = {}

	_parent = null
    _extent = null
    _origin = [10, 20]

    function getOrigin( value ) { return :_origin }
    function setorigin( value ) { :_origin = value }

	this()
    {
		foreach (name, field; fieldsOf( View ))
		{
			if (name.startsWith( "get" ))
				:_getters[ name[3..].toLower() ] = field
			if (name.startsWith( "set" ))
				:_setters[ name[3..].toLower() ] = field
		}
    }

	function opField( name )
	{
		if (name in :_getters)
			return (:_getters[ name ])( with this )
	}

	function opFieldAssign( name, value )
	{
		if (name in :_setters)
			(:_setters[ name ])( with this, value )
	}
}

local view = View()

writeln( view.origin )

