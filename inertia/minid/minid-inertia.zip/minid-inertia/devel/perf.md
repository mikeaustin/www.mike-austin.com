module perf

class Foo
{
    this()
    {
        :origin = Vector.fromArray( "i16", [10, 10, 10] )
        :_y = 10
        :z  = 10
    }

    function x() = :origin[0]
    function y() = :_y
}

local foo = Foo()
local a

for (i; 0..10000000)
{
//    a = foo.x() // 27.3
//    a = foo.y() // 14.4
//    a = foo.z   // 4.4
}

