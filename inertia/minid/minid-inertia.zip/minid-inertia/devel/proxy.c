#include <sys/types.h>
#ifdef _WIN32
 #define _WIN32_WINNT 0x0501
 #include <winsock2.h>
 #include <ws2tcpip.h>
#else
 #include <fcntl.h>
 #include <sys/socket.h>
 #include <netdb.h>
#endif
#include <string.h>
#include <stdio.h>

char buffer[4096];
int sock;
fd_set sockets;
int input;

void init()
{
    input = fileno( stdin );

    char host[] = "irc.freenode.net";
    char port[] = "8001";

    struct addrinfo hints, *info;
    memset( &hints, 0, sizeof( hints ) );
    hints.ai_family   = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags    = AI_NUMERICSERV;

    int result = getaddrinfo( host, port, &hints, &info );
    //printf( "getaddrinfo = %i\n", result );

    sock = socket( info->ai_family, info->ai_socktype, info->ai_protocol );
    //printf( "socket = %i\n", sock );

    result = connect( sock, info->ai_addr, info->ai_addrlen );
    //printf( "connect = %i\n", result );

    freeaddrinfo( info );
}

void sendData( char* string )
{
    int result = send( sock, string, strlen( string ), 0 );

    printf( "send() = %i\n", result );
}

void recvData()
{
    int length = recv( sock, buffer, 4096, 0 );

    printf( "recv = %i\n", length );

    buffer[length] = '\0';
}

void pollData()
{
    FD_ZERO( &sockets );
    FD_SET( input, &sockets );
    FD_SET( sock, &sockets );

    struct timeval timeout;
    timeout.tv_sec = 1;
    timeout.tv_usec = 100000;

    select( FD_SETSIZE, &sockets, 0, 0, &timeout );
}

int main( int argc, char *argv[] )
{
    init();

    sendData( "user maustin3 0 0 :Mike Austin\r\n" );
    sendData( "nick maustin3\r\n" );
    sendData( "join #testirc\r\n" );

    for (;;)
    {
        pollData();

        if (FD_ISSET( input, &sockets ))
        {
            int bytes = read( input, buffer, 256 );
            buffer[bytes] = '\0';

            if (strlen( buffer ) != bytes)
            {
                if (strlen( buffer ) > 0)
                    sendData( buffer );

                printf( "\n" );

                if (strlen( buffer + strlen( buffer ) + 2 ) > 0)
                    sendData( buffer + strlen( buffer ) + 2 );
            }
            else
                sendData( buffer );
        }
        else if (FD_ISSET( sock, &sockets ))
        {
            recvData();

            printf( "%s", buffer );
        }

        fflush( stdout );
    }

    sendData( "quit\r\n" );

    return 0;
}

