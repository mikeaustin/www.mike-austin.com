module inertia

import bar
import foo.baz

loadString( io.readFile( "qip.md" ) )()

writeln( bar.Bar )
writeln( foo.baz.Baz )
writeln( Qip )

writeln()

foreach (name, value; modules.loaded)
    writeln( name )

writeln()

foreach (name, value; modules.customLoaders)
    writeln( name )

