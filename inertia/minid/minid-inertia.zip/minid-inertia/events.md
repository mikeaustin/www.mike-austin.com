module inertia.events

import core.view

class Action
{
    target
    action
    args
    
    this( target, action: string, varargs )
    {
        :target = target
        :action = action
        :args   = [varargs]
    }
    
    function invoke( varargs )
    {
        //:target.(:action)( (:args ~ [varargs]).expand() )
        :target.(:action)( varargs )
    }
}

class Event
{
    type = null

    this( type: string )
    {
        :type = type
    }
}

class MouseEvent : Event
{
    point
    button

    this( type: string, point: array|Vector, button: int )
    {
        super( type )

        //:point = point.toVector( "i16" )
        if (typeof(point) == "array")
            :point = Vector.fromArray( "i16", point )
        else
            :point = point
            
        :button = button
    }

    //function dispatchEvent( viewx: core.view.View )
    function dispatchEvent( view )
    {
        foreach (child; view.children, "reverse")
        {
            local point = :point - child.origin

            if (child.containsPoint( point ))
            {
                if (view.focused && !(view.focused is child))
                {
                    view.focused.focusLost()
                }

                if (:type == "mouseDown")
                {
                    view.focused = child

                    child.focusGained()
                }

                return child.sendEvent( MouseEvent( :type, [point[0], point[1]], :button ) )
            }
        }

        view.handleEvent( this )
        
        return view
    }
}

class KeyEvent : Event
{
    keysym
    modifiers
    char
    
    this( type: string, keysym: int, modifiers: int, char: char )
    {
        super( type )
        
        :keysym = keysym
        :modifiers = modifiers
        :char = char
    }
    
    function dispatchEvent( view )
    {
        if (view.focused)
            return view.focused.sendEvent( this )

        view.handleEvent( this )
        
        return view
    }
}

class ShapeEvent : Event
{
    extent
    
    this( type: string, extent: Vector )
    {
        super( type )
        
        :extent = extent
    }
    
    //function dispatchEvent( viewx: core.view.View )
    function dispatchEvent( view )
    {
        view.handleEvent( this )
    }
}

