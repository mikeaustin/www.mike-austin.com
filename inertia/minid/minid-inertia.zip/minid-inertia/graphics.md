module inertia.graphics

class Color
{
    color = Vector.fromArray( "f32", [0.0, 0.0, 0.0] )
    
    this( r, g, b )
    {
        :color = Vector.fromArray( "f32", [r, g, b] )
    }
    
    White = Color( 1.0, 1.0, 1.0 )
}

class FileModel
{
    this()
    {
        :data = []
        
        foreach (i, path; io.listFiles("/usr/bin").sort())
        {
            try
            {
                local name = StringBuffer( io.name( path ) ~ (io.extension( path ) != "" ? "." : "") ~ io.extension( path ) )
                local size = StringBuffer( toString( io.size( path ) ) )
                local modified = StringBuffer( time.dateString( "g", io.modified( path ) ) )
            
                :data.append( {name = name, size = size, modified = modified} )
            }
            catch (error)
            {
                writeln( "Error: " ~ error )
            }
        }
    }
}

function loadRGB( path: string )
{
    local file = io.inFile( path )
    local rgb = file.readVector( "u8", file.size() )
    file.close()

    local rgba = Vector( "u8", 0 )
    foreach ( i, v; rgb )
    {
        rgba.append( 0 )

        if (i % 3 == 2) rgba.append( rgb[ i ] )
    }
    
    return rgba
}

class Canvas
{
    font = null
    base = null

    this()
    {
        :font2 = graphics.loadRGB( "images/sysfont2.rgb" )
        :base  = gl.glGenLists( 127 )
        :chars = []

        :pushMatrix = gl.glPushMatrix
        :popMatrix  = gl.glPopMatrix
        :begin      = gl.glBegin
        :end        = gl.glEnd
        :rasterPos  = gl.glRasterPos2i
        :vertex     = gl.glVertex2f
        :translate  = gl.glTranslatef
        :color      = gl.glColor3f
        :colorAlpha = gl.glColor4f
        :rotate     = gl.glRotatef

        foreach (i, c; " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")
        {
            gl.glNewList( :base, gl.GL_COMPILE )
                gl.glPixelStorei( gl.GL_UNPACK_ROW_LENGTH, 8 )
                gl.glPixelZoom( 1, -1 )

                gl.glColor3f( 0.0, 0.0, 0.0 )
            gl.glEndList()
            
            gl.glNewList( :base + i + 31, gl.GL_COMPILE )
                local offset = (toInt( c ) - 32) * 4 * 8 * 17
                local char = :font2[offset..offset + 4 * 8 * 17]
                :chars.append( char )
                gl.glDrawPixels( 8, 17, gl.GL_RGBA, gl.GL_UNSIGNED_BYTE, char )

                gl.glTranslatef( 8, 0, 0 )
                gl.glRasterPos2i( 0, 0 )
            gl.glEndList()
        }
    }
    
    zero  = Vector.fromArray( "i16", [0, 0] )

    function drawLine( xy: array|Vector, wh: array|Vector )
    {
        gl.glBegin( gl.GL_LINES )
            gl.glVertex2f( xy[0] + 0.5, xy[1] - 0.5 )
            gl.glVertex2f( wh[0] - 0.5, wh[1] - 0.5 )
        gl.glEnd()
    }
    
    function drawLineRect( xy: array|Vector, wh: array|Vector )
    {
        gl.glBegin( gl.GL_LINE_LOOP )
            gl.glVertex2f( xy[0] + 0.5, xy[1] - 0.5 )
            gl.glVertex2f( wh[0] - 0.5, xy[1] - 0.5 )

            gl.glVertex2f( wh[0] + 0.5, xy[1] + 0.5 )
            gl.glVertex2f( wh[0] + 0.5, wh[1] - 0.5 )

            gl.glVertex2f( wh[0] - 0.5, wh[1] + 0.5 )
            gl.glVertex2f( xy[0] + 0.5, wh[1] + 0.5 )

            gl.glVertex2f( xy[0] - 0.5, wh[1] - 0.5 )
            gl.glVertex2f( xy[0] - 0.5, xy[1] + 0.5 )
        gl.glEnd()
    }

    function drawSolidRect( xy: array|Vector, wh: array|Vector )
    {
        gl.glRectf( xy[0], xy[1], xy[0] + wh[0], xy[1] + wh[1] )
    }

    function drawImage( image: Vector, width: int, height: int )
    {
        if (width * height * 4 <= #image)
            gl.glDrawPixels( width, height, gl.GL_RGBA, gl.GL_UNSIGNED_BYTE, image )
        else
            writeln( "Canvas.drawImage(): Image too small for width and height arguments" )
    }

    function drawImageRGB( image: Vector, width: int, height: int )
    {
        gl.glPixelStorei( gl.GL_UNPACK_ROW_LENGTH, width )

        if (width * height * 4 <= #image)
            gl.glDrawPixels( width, height, gl.GL_RGB, gl.GL_UNSIGNED_BYTE, image )
        else
            writeln( "Canvas.drawImageRGB(): Image too small for width and height arguments" )
    }
    
    function stringWidth( str: Vector ) = #str * 8
    
    function drawString( str: Vector )
    {
        gl.glCallList( :base )
        gl.glPushMatrix()
            gl.glRasterPos2i( 0, 0 )
            gl.glCallLists( #str, gl.GL_UNSIGNED_INT, str )
        gl.glPopMatrix()
    }
}

