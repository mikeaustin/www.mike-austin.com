//
// game_rocks.h
//

#ifndef game_rocks_h
#define game_rocks_h

#include "engine/game.h"
#include "engine/objects.h"

/* class Ship *\_______________________________________________________________

   Provides core functionality for objects such as movement, rotation and
   collisions
____________________________________________________________________________
                                                                            \*/
class Ship : public Object {
 public:
 // Initialize type name, radius and member vars
    Ship() : Object( "Ship" ), _spin(0) { radius() = 7; }
    virtual void advanceObject();
    virtual void renderObject();
    virtual void collidedObject( Object *object );

 private:
    int _spin;   // Used to count spins after collision
};

/* class Rock *\_______________________________________________________________

   Provides core functionality for objects such as movement, rotation and
   collisions
____________________________________________________________________________
                                                                            \*/
class Rock : public Object {
 public:
 // Initialize type name, radius and vertex data
    Rock() : Object( "Rock" ) {
        radius() = 20;
        initShape();
    }
    Rock( Rock* rock ) : Object( "Rock" ) {
        *this = *rock;
        initShape();
    }
 // Calculate vertexes for pentagon 'rock'                                                                            \*/
    void initShape();
 // Render the rock
    virtual void renderObject();
 // The rock collided with something
    virtual void collidedObject( Object *object );

 private:
    Vector _rockData[6];
};

/* class Laser *\______________________________________________________________

   Provides core functionality for objects such as movement, rotation and
   collisions
____________________________________________________________________________
                                                                            \*/
class Laser : public Object {
 public:
 // Initialize type name, radius and life counter
    Laser() : Object( "Laser" ), _life(200) { radius() = 1; }
    virtual void advanceObject();
    virtual void renderObject();
    virtual void collidedObject( Object *object );

 private:
    float _life;
};

/* Game Modes *\_______________________________________________________________

   Provides core functionality for objects such as movement, rotation and
   collisions
____________________________________________________________________________
                                                                            \*/
class DemoMode : public Mode {
    virtual void keyUp( int key );
    virtual void renderScreen();
};

class PlayMode : public Mode {
    virtual void keyDown( int key );
    virtual void keyUp( int key );
    virtual void renderScreen();
};

/* class Rocks *\______________________________________________________________

   Provides core functionality for objects such as movement, rotation and
   collisions
____________________________________________________________________________
                                                                            \*/
class Rocks : public Game {
 public:
    Rocks( int argc, char* argv[] );
 // Destroys objects, creates ship, rocks and enters PlayMode
    void newGame();
 // Initialize rock objects with count rocks
    void initRocks( int count );

 // Accessor methods
    int& score() { return _score; }
    int& lives() { return _lives; }
    Ship*& ship() { return _ship; }
    int& level() { return _level; }
    DemoMode  demoMode;
    PlayMode  playMode;
    Object *rock;  // temp: first rock colored for debugging

 // Fire a laser from the player's ship
    void fireLaser();
 // Draws some help at bottom of screen
    void drawHelp();
 // Draws player's score and lives at top right
    void drawScore();
 // Draws a stary background
    void drawStars();

 protected:
    virtual void sizeChange( int width, int height );
    virtual void nextLevel();
    friend class GameMode;

 private:
    Ship *_ship;
    int   _score;  // The player's score
    int   _lives;  // Number of lives left
    int   _level;  // The game level
};

extern Rocks *game;

#endif

