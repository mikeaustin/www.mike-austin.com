//
// glutapi.cpp
//

#include "glutapi.h"
#include <gl/glut.h>

class Game;

void GlutApi::initDisplay( Game* game ) {
 // Initialize glut and window
    glutInit( &game->argc(), game->argv() );
 // Enable double-buffer and alpha-blending 
    glutInitDisplayMode( GLUT_DOUBLE | GLUT_RGBA );
 // Center window on screen
    glutInitWindowPosition( glutGet( GLUT_SCREEN_WIDTH ) / 2 - g_config.windowWidth / 2,
                            glutGet( GLUT_SCREEN_HEIGHT ) / 2 - g_config.windowHeight / 2 );
    glutInitWindowSize( g_config.windowWidth, g_config.windowHeight );
    glutCreateWindow( "Rocks!" );

 // Turn on blending and line smothing
    glEnable( GL_BLEND );
    glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );
    glEnable( GL_LINE_SMOOTH );
    glLineWidth( g_config.lineWidth );
    glEnable( GL_POINT_SMOOTH );
    glPointSize( 1.5 );

 // Setup glut callback functions
    glutDisplayFunc( displayCallback );
    glutKeyboardFunc( keyboardCallback );
    glutSpecialFunc( specialCallback );
    glutKeyboardUpFunc( keyboardUpCallback );
    glutSpecialUpFunc( specialUpCallback );
    glutReshapeFunc( reshapeCallback );
    glutIdleFunc( idleCallback );

 // Turn off key repeat
    glutIgnoreKeyRepeat( 1 );
}

// GLUT callback functions

   void keyboardCallback( unsigned char key, int x, int y ) {
       _g_game->keyDown( (int)key );
   }

   void specialCallback( int key, int x, int y ) {
       _g_game->keyDown( key + 128 );
   }

   void keyboardUpCallback( unsigned char key, int x, int y ) {
       _g_game->keyUp( key );
   }

   void specialUpCallback( int key, int x, int y ) {
       _g_game->keyUp( key + 128 );
   }

   void displayCallback() {
       _g_game->display();
   }

// Called when the window is resised or initialized
   void reshapeCallback( int width, int height ) {
    // Save new window dimmensions
       //g_game.out << "reshapeCallback" << endl;
       g_config.windowWidth  = width;
       g_config.windowHeight = height;
       g_config.coordsWidth  = g_config.windowWidth / 4;
       g_config.coordsHeight = g_config.windowHeight / 4;

    // Set viewport to window dimmensions
       glViewport( 0, 0, g_config.windowWidth, g_config.windowHeight );
    // Setup our coordinate system
       glMatrixMode( GL_PROJECTION );
       glLoadIdentity();
       gluOrtho2D( -g_config.coordsWidth, g_config.coordsWidth,
                   -g_config.coordsHeight, g_config.coordsHeight );
       glMatrixMode( GL_MODELVIEW );

    // Call the game engine's resize callback
       _g_game->sizeChange( width, height );
   }

   void idleCallback() {
       _g_game->idleTick();
   }

