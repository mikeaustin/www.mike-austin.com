//
// utils.h
//

#ifndef utils_h
#define utils_h

/* class Vector *\_____________________________________________________________

   A nice, simple templated linked list class -- STL is too heavy
____________________________________________________________________________
                                                                            \*/
class Vector {
 public:
    Vector() : _x(0), _y(0) { }
    Vector( float x, float y ) : _x(x), _y(y) { }
    float& x() { return _x; }
    float& y() { return _y; }

 private:
    float _x, _y;
};

/* class List *\_______________________________________________________________

   A nice, simple templated linked list class -- STL is too heavy
____________________________________________________________________________
                                                                            \*/
template<typename T> class List {
 public:
 // Internal node structure for each item in list
    class Node {
     public:
     // Construct initializes member variables
        Node( Node *prev, Node *next, T* data ) :
         _prev(prev), _next(next), _data(data) { }

     // Accessors help separate interface from implimentation
        Node*& next() { return _next; }
        Node*& prev() { return _prev; }
        T*& data() { return _data; }

     private:
     // Pointers to the previous and next nodes, and data
        Node  *_prev, *_next;
        T     *_data;
    };

 // Construct initializes member variables
    List<T>() : _first(0), _last(0) { }

 // Appends a node to the list and points to data
    void append( T* data ) {
        Node* node = new Node( last(), 0, data );
        if( last() ) {
            _last->next() = node;
        } else {
            first() = node;
        }
        last() = node;
    }

 // Removes a node from the list, does not delete data
    Node* remove( Node* node ) {
        if( node == NULL )
            return 0;

        if( node == first() ) {
            first() = node->next();
        } else {
            node->prev()->next() = node->next();
        }
        if( node == last() ) {
            last() = node->prev();
        } else {
            node->next()->prev() = node->prev();
        }

        return node->next();
    }
    void empty() {
        Node* node = first();
        while( node ) {
            node = remove( node );
        }
    }

 // Accessors help separate interface from implimentation
    Node*& first() { return _first; }
    Node*& last() { return _last; }

 private:
 // Pointers to the the first and last nodes
    Node*  _first;
    Node*  _last;
};

#endif

