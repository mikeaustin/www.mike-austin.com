//
// game.cpp
//

#include <gl/gl.h>
#include <gl/glut.h>
#include <math.h>
#include <stdlib.h>
#include <iostream>
//#include <list>
#include "utils.h"
#include "game.h"
#include "objects.h"

/* Misc Stuff *\---------------------------------------------------------------
----------------------------------------------------------------------------
                                                                            \*/
Control g_control;
Config  g_config = {
    800, 600,    // windowWidth, windowHeight
    0, 0,        // coors -- calculated later
    true,        // colorBeam
    .75, 1.5,    // lineAlpha, lineWidth
    true,        // pointLight
    .5,          // lineFlicker
};
Game *_g_game;

int   timeWarp     = 0;
bool  degradeFps   = false;
int   g_objects    = 0;

int oldtime = 0, newtime;
//INT64 woldtime = 0, wnewtime;
float deltaTime;

int frames = 0;
float timer = 0;

#define foreach( iter, coll ) \
 for( iter = coll.begin(); iter != coll.end(); iter++ )

void setColor( Color color ) {
    if( g_config.colorBeam ) {
        _g_game->currentColor() = color;
     // todo: push to Api
        glColor4f( color.red(), color.green(), color.blue(),
         g_config.lineAlpha * _g_game->currentColor().alpha() );
    }
}

void setAlpha( float alpha ) {
    _g_game->currentColor().alpha() = alpha;
    Color& color = _g_game->currentColor();
 // todo: push to Api
    glColor4f( color.red(), color.green(), color.blue(),
     g_config.lineAlpha * _g_game->currentColor().alpha() );
}

/* class Game *\_______________________________________________________________

   Provides core functionality for objects such as movement, rotation and
   collisions
____________________________________________________________________________
                                                                            \*/
Game::Game( int argc, char* argv[], Api* aapi ) :
     out(&_sb) {
     // Initialize everything
        _g_game = this;
        _api = aapi;
        _argc = argc;
        _argv = argv;
        api()->initDisplay( this );
        //_rc = QueryPerformanceFrequency( (LARGE_INTEGER*)&_perfFreq );
}

void Game::drawLineStrip( Vector data[], int verts ) {
    drawPrimitive( data, verts, GL_LINE_STRIP );
}

void Game::drawLines( Vector data[], int verts ) {
    drawPrimitive( data, verts, GL_LINES );
}

void Game::drawPrimitive( Vector data[], int verts, int type ) {
    Color color = _g_game->currentColor();
    glBegin( type );
      for( int i = 0; i < verts; i++ ) {
          glColor4f( color.red(), color.green(), color.blue(), color.alpha() * g_config.lineAlpha *
           (((rand() / (float)RAND_MAX) * g_config.beamFlicker) + (1 - g_config.beamFlicker)) );
           //api->setColor( color );
           //api->setAlpha( (((rand() / (float)RAND_MAX) * g_config.beamFlicker) +
            //(1 - g_config.beamFlicker)) ) );
          glVertex2f( data[i].x(), data[i].y() );
      }
    glEnd();
    if( g_config.pointLight ) {
        glBegin( GL_POINTS );
          for( int i = 0; i < verts; i ++ ) {
              glVertex2f( data[i].x(), data[i].y() );
        }
        glEnd();
    }
}

void Game::detectCollisions() {
    List<Object>::Node *iter1, *iter2;
    Object *obj1, *obj2;
    float distance;
    bool collision = false;
 // For each object, compare distance to other objects
    for( iter1 = objects().first(); iter1 != 0; iter1 = iter1->next() ) {
        obj1 = iter1->data();
        for( iter2 = objects().first(); iter2 != 0; iter2 = iter2->next() ) {
            obj2 = iter2->data();
         // If we are not the same object
            if( obj2 != obj1 ) {
                distance = obj1->distanceTo( obj2 );
             // If in collision range and objects are not currently in collided state
                if( distance < (obj1->radius() + obj2->radius()) ) {
                    collision = true;
                    if( obj1->collided() == false ) {
                     // Set the object's collided flag so we don't keep calling
                        obj1->collided() = true;
                     // Call the object's collidedObject event
                        obj1->collidedObject( obj2 );
                    }
                }
            }
        }
//        if( collision == false )  Causes overlapping rocks to be 'invincible'
            obj1->collided() = false;
    }
}

   void Game::display() {
    // Clear the screen and any transformations
       //glClear( GL_COLOR_BUFFER_BIT );
       glLoadIdentity();
       glColor4f( 0, 0, 0, (timeWarp / 100.0) * (timeWarp / 10.0) );
       //glColor4f( 0, 0, 0, timeWarp / 100.0 );
       glBegin( GL_QUADS );
         glVertex2f( -g_config.coordsWidth, -g_config.coordsHeight );
         glVertex2f( -g_config.coordsWidth,  g_config.coordsHeight );
         glVertex2f(  g_config.coordsWidth,  g_config.coordsHeight );
         glVertex2f(  g_config.coordsWidth, -g_config.coordsHeight );
       glEnd();

    // Render the background scene if any
       renderScreen();

    // Render the ship and rock objects
       List<Object>::Node* iter;
       for( iter = objects().first(); iter != 0; iter = iter->next() ) {
           iter->data()->render();
       }

    // Swap the double-buffered image
       glutSwapBuffers();
   }

   void Game::idleTick() {
    // Gradually warp users time to normal/slow
       if( g_control.timeWarp ) {
           if( timeWarp > 10 ) timeWarp -= 5;
       } else {
           if( timeWarp < 100 ) timeWarp += 1;
       }

    // Degrade frames per second for visual debugging
       if( degradeFps )
           for( int i = 0; i < 5000000; i++ );

    // Calculate delta time changes for animation
       newtime = glutGet( GLUT_ELAPSED_TIME );
       deltaTime = (newtime - oldtime);
       //newtime = GetTickCount();
       //_rc = QueryPerformanceCounter( (LARGE_INTEGER*)&_perfCount );
       //newtime = _perfCount;
       //deltaTime = (wnewtime - woldtime) / (_perfFreq / 1000.0);
       //deltaTime = 15;
       oldtime = newtime;

       frames++;
       if( newtime - timer >= 100 ) {
           //cout << deltaTime << " " << flush;
           timer = newtime;
       }
   /*  if( newtime - timer >= 500 ) {
           g_game.out << "\rship.x:" << g_ship->x() << "        "
                << "\r\t\t ship.y:" << g_ship->y() << "        "
                << "\r\t\t\t\t  fps:" << frames * 2 << "        "
                << "\r\t\t\t\t\t\tdelta: " << deltaTime << "        "
                << "\r\t\t\t\t\t\t\t\twarp: " << timeWarp << "        "
                << "\r\t\t\t\t\t\t\t\t\t\tobjs: " << g_objects << "        "
                << flush;
           timer = newtime;
           frames = 0;
       }*/

    // Advance the ship and rock objects
       g_objects = 0;
       List<Object>::Node *node = objects().first(), *temp;
       while( node != 0 ) {
           g_objects++;
           node->data()->advance();
           if( node->data()->dispose() == true ) {
               temp = node;
               node = objects().remove( node );
               delete temp;
           } else {
               node = node->next();
           }
       }

    // Test and process any object collisions
       detectCollisions();

    // Tell glut to update the display
       glutPostRedisplay();
   }

   void Game::keyDown( int key ) {
       if( key == Game::KeyF1 ) {
           setColor( Color( 1, 1, 1 ) );
           g_config.colorBeam = !g_config.colorBeam;
           cout << "colorBeam = " << g_config.colorBeam << endl;
       }
       if( key == Game::KeyF2 ) {
           g_config.pointLight = !g_config.pointLight;
           cout << "pointLight = " << g_config.pointLight << endl;
       }
       if( key == Game::KeyF3 ) {
           if( g_config.beamFlicker <= 1.0 ) g_config.beamFlicker += .1;
           cout << "beamFlicker = " << g_config.beamFlicker << endl;
       }
       if( key == Game::KeyF4 ) {
           if( g_config.beamFlicker >= 0.0 ) g_config.beamFlicker -= .1;
           cout << "beamFlicker = " << g_config.beamFlicker << endl;
       }
       if( key == Game::KeyF5 ) {
           if( g_config.lineAlpha <= 1.0 ) g_config.lineAlpha += .1;
           cout << "lineAlpha = " << g_config.lineAlpha << endl;
       }
       if( key == Game::KeyF6 ) {
           if( g_config.lineAlpha >= 0.0 ) g_config.lineAlpha -= .1;
           cout << "lineAlpha = " << g_config.lineAlpha << endl;
       }
       if( key == Game::KeyF7 ) {
           if( g_config.lineWidth <= 10.0 ) g_config.lineWidth += .1;
           glLineWidth( g_config.lineWidth );
           cout << "lineWidth = " << g_config.lineWidth << endl;
       }
       if( key == Game::KeyF8 ) {
           if( g_config.lineWidth >= 0.0 ) g_config.lineWidth -= .1;
           glLineWidth( g_config.lineWidth );
           cout << "lineWidth = " << g_config.lineWidth << endl;
       }
       mode()->keyDown( key );
   }
