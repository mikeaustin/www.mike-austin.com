//
// glutapi.h
//

#ifndef glutapi_h
#define glutapi_h

#include "game.h"

class GlutApi : public Api {
 public:
    void initDisplay( Game *game );
    void mainLoop() { glutMainLoop(); }
};

void keyboardCallback( unsigned char key, int x, int y );
void specialCallback( int key, int x, int y );
void keyboardUpCallback( unsigned char key, int x, int y );
void specialUpCallback( int key, int x, int y );
void displayCallback();
void reshapeCallback( int width, int height );
void idleCallback();

#endif

