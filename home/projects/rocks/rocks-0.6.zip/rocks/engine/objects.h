//
// objects.h
//

#ifndef objects_h
#define objects_h

#include <iostream.h>
#include <string>
#include <gl/gl.h>
#include <math.h>
#include "game.h"

/* class Object *\_____________________________________________________________

  Provides core functionality for objects such as movement, rotation and
  collisions
____________________________________________________________________________
                                                                            \*/
class Object {
 public:
    Object( string type ) : _pos(0, 0), _angle(0),
     _xvel(0), _yvel(0), _spinvel(0), _radius(0),
     _collided(false), _dispose(false), _type(type) { }

 // Advance the object in game time
    void advance();
 // Render the object, applying location and rotation
    void renderTransform();
 // Draws extra 2 times to draw image overlap in x and y
    void render();

    virtual void renderObject() = 0;
    virtual void advanceObject() { }
    //virtual void collidedObject( Object *object ) { collided() = false; }
    virtual void collidedObject( Object *object ) { }

    float distanceTo( Object* object ) {
     // Compute using distance formula
        return sqrt( pow(x() - object->x(), 2) + pow(y() - object->y(), 2) );
    }

     Vector& pos() { return _pos; }
      float& x() { return _pos.x(); }
      float& y() { return _pos.y(); }
      float& xvel() { return _xvel; }
      float& yvel() { return _yvel; }
      float& spinvel() { return _spinvel; }
      float& angle() { return _angle; }
      float& radius() { return _radius; }
       bool& collided() { return _collided; }
       bool& dispose() { return _dispose; }
     string& type() { return _type; }

 private:
    Vector _pos;
    float  _angle;
    float  _xvel, _yvel;
    float  _spinvel;
    float  _radius;
    bool   _collided;
    bool   _dispose;
    string _type;
};

#endif

