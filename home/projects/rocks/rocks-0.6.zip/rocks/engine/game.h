//
// game.h
//

#ifndef game_h
#define game_h

#include <list>
#include "utils.h"
#include <gl/glut.h>
//#include <w32api/windows.h>

#define D2R(angle)  angle * (M_PI / 180)

class Control {
 public:
    bool rotateLeft;
    bool rotateRight;
    bool thrust, fire;
    bool timeWarp;
};

struct Config {
    int   windowWidth;
    int   windowHeight;
    int   coordsWidth;
    int   coordsHeight;
    bool  colorBeam;
    float lineAlpha;
    float lineWidth;
    bool  pointLight;
    float beamFlicker;
};

class Object;
class Game;

extern Game* _g_game;

class Color {
 public:
    Color() {
        _color[0] = _color[1] = _color[2] = 1;
        _color[3] = 1.0;
    }
    Color( float red, float green, float blue ) {
        setRGB( red, green, blue );
        setAlpha( 1.0 );
    }
    void setRGB( float red, float green, float blue ) {
        _color[0] = red;  _color[1] = green;  _color[2] = blue;
    }
    void setAlpha( float alpha ) {
        _color[3] = alpha;
    }

    float& red() { return _color[0]; }
    float& green() { return _color[1]; }
    float& blue() { return _color[2]; }
    float& alpha() { return _color[3]; }

 private:
    float  _color[4];
};

void setColor( Color color );
void setAlpha( float alpha );

/* class Api *\________________________________________________________________

   Provides core functionality for objects such as movement, rotation and
   collisions
____________________________________________________________________________
                                                                            \*/
class Api {
 public:
    virtual void initDisplay( Game *game ) = 0;
    virtual void display() { };
    virtual void keyDown() { };
    virtual void keyUp() { };
    virtual void mainLoop() = 0;
};

class Mode {
 public:
    virtual void keyDown( int key ) { };
    virtual void keyUp( int key ) { };
    virtual void renderScreen() { };
};

/* class Game *\_______________________________________________________________

   Provides core functionality for objects such as movement, rotation and
   collisions
____________________________________________________________________________
                                                                            \*/
class Game {
 public:
    Game( int argc, char* argv[], Api* aapi );
    Api* api() { return _api; }

 // Enters the game's main loop and processes events
    void mainLoop() { api()->mainLoop(); }
 // Called after posting a redisplay request
    void display();
 // Called as often as possible, not timed
    void idleTick();
    void keyDown( int key );
    void keyUp( int key ) { mode()->keyUp( key ); }
    void renderScreen() { mode()->renderScreen(); }

    virtual void sizeChange( int width, int height ) { }
    virtual void nextLevel() { }

 /* Traverses the objects list and tests for collisions
    It calls the object's collidedObject(Object*) with the collided
    object as the argument */
    void detectCollisions();

    void drawLineStrip( Vector data[], int verts );
    void drawLines( Vector data[], int verts );

    List<Object>& objects() { return _objects; }
    Color&  currentColor() { return _currentColor; }
    int&    argc() { return _argc; }
    char**  argv() { return _argv; }
    Mode*&  mode() { return _mode; }

 protected:
    void drawPrimitive( Vector data[], int verts, int type );

 private:
    List<Object> _objects;
    Color    _currentColor;
    filebuf _sb;
    int     _argc;
    char**  _argv;
    Api*    _api;
    Mode*   _mode;
    bool    _rc;
    //INT64   _perfFreq;
    //INT64   _perfCount;

 public:
    ostream out;
    enum keys {
        KeyLeft  = 128 + GLUT_KEY_LEFT,
        KeyRight = 128 + GLUT_KEY_RIGHT,
        KeyUp    = 128 + GLUT_KEY_UP,
        KeyDown  = 128 + GLUT_KEY_DOWN,
        KeyF1    = 128 + GLUT_KEY_F1,
        KeyF2    = 128 + GLUT_KEY_F2,
        KeyF3    = 128 + GLUT_KEY_F3,
        KeyF4    = 128 + GLUT_KEY_F4,
        KeyF5    = 128 + GLUT_KEY_F5,
        KeyF6    = 128 + GLUT_KEY_F6,
        KeyF7    = 128 + GLUT_KEY_F7,
        KeyF8    = 128 + GLUT_KEY_F8,
    };
};

extern Control g_control;
extern Config  g_config;

extern int   timeWarp;
extern bool  degradeFps;
extern int   g_objects;

extern int   oldtime, newtime;
//extern INT64   woldtime, wnewtime;
extern float deltaTime;

#endif

