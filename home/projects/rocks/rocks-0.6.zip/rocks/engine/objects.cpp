//
// objects.cpp
//

#include <gl/gl.h>
#include <math.h>
#include <list>
#include "objects.h"
#include "game.h"

/* class Object *\_____________________________________________________________

  Provides core functionality for objects such as movement, rotation and
  collisions
____________________________________________________________________________
                                                                            \*/
   void Object::advance() {
     // Move the object according to it's velocities
       pos().x() += _xvel * (timeWarp * .01) * (deltaTime * .1);
       pos().y() += _yvel * (timeWarp * .01) * (deltaTime * .1);
    // If the object runs out of bounds, wrap to other side(s)
       if( x() >  g_config.coordsWidth )  x() += -g_config.coordsWidth * 2;
       if( x() < -g_config.coordsWidth )  x() +=  g_config.coordsWidth * 2;
       if( y() >  g_config.coordsHeight ) y() += -g_config.coordsHeight * 2;
       if( y() < -g_config.coordsHeight ) y() +=  g_config.coordsHeight * 2;
    // Rotate object according to spin velocity
       _angle += _spinvel * (timeWarp * .01) * (deltaTime * .1);
    // Call the inherited object's advance method
       advanceObject();
   }

   void Object::renderTransform() {
       glTranslatef( x(), y(), 0 );
       glRotatef( angle(), 0, 0, 1 );
    // Call the inherited object's render method
       renderObject();
   }

   void Object::render() {
       glPushMatrix();
      // Draw in normal location
         renderTransform();

      // Draw wrapped x image
         glLoadIdentity();
         glTranslatef( (x() > 0 ? -g_config.coordsWidth * 2 : g_config.coordsWidth * 2), 0, 0 );
         renderTransform();

      // Draw wrapped y image
         glLoadIdentity();
         glTranslatef( 0, (y() > 0 ? -g_config.coordsHeight * 2 : g_config.coordsHeight * 2), 0 );
         renderTransform();
       glPopMatrix();
   }

