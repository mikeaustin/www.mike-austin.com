#include <gl/gl.h>
#include <math.h>
#include <list>
#include "objects.h"
#include "init.h"

/* class Object *\_____________________________________________________________

  Provides core functionality for objects such as movement, rotation and
  collisions
____________________________________________________________________________
                                                                            \*/
// Advance the object in game time
   void Object::advance() {
     // Move the object according to it's velocities
       _x += _xvel * (timeWarp * .01) * (deltaTime * .1);
       _y += _yvel * (timeWarp * .01) * (deltaTime * .1);
    // If the object runs out of bounds, wrap to other side(s)
       if( _x >  g_config.coordsWidth )  _x += -g_config.coordsWidth * 2;
       if( _x < -g_config.coordsWidth )  _x +=  g_config.coordsWidth * 2;
       if( _y >  g_config.coordsHeight ) _y += -g_config.coordsHeight * 2;
       if( _y < -g_config.coordsHeight ) _y +=  g_config.coordsHeight * 2;
    // Rotate object according to spin velocity
       _angle += _spinvel * (timeWarp * .01) * (deltaTime * .1);
    // Call the inherited object's advance method
       advanceObject();
   }

// Render the object, applying location and rotation
   void Object::renderTransform() {
       glTranslatef( _x, _y, 0 );
       glRotatef( _angle, 0, 0, 1 );
    // Call the inherited object's render method
       renderObject();
   }

// Draws extra 2 times to draw image overlap in x and y
   void Object::render() {
       glPushMatrix();
      // Draw in normal location
         renderTransform();

      // Draw wrapped x image
         glLoadIdentity();
         glTranslatef( (x() > 0 ? -g_config.coordsWidth * 2 : g_config.coordsWidth * 2), 0, 0 );
         renderTransform();

      // Draw wrapped y image
         glLoadIdentity();
         glTranslatef( 0, (y() > 0 ? -g_config.coordsHeight * 2 : g_config.coordsHeight * 2), 0 );
         renderTransform();
       glPopMatrix();
   }

/* class Ship *\_______________________________________________________________

   Provides core functionality for objects such as movement, rotation and
   collisions
____________________________________________________________________________
                                                                            \*/
    void Ship::advanceObject() {
     // While the player is pressing left, rotate left
        if( g_control.rotateLeft == true )
            angle() += 3 * (deltaTime * .1);
     // While the player is pressing right, rotate left
        if( g_control.rotateRight == true )
            angle() -= 3 * (deltaTime * .1);
     // If they are holding down thrus, then thrust
        if( g_control.thrust == true ) {
         // Add velocity to pointed direction
            xvel() -= .01 * sin( D2R(angle()) ) * (deltaTime * .1);
            yvel() += .01 * cos( D2R(angle()) ) * (deltaTime * .1);
        }
     // If we hit something, spin a few times
        //if( collided() == true ) {
        if( _spin > 0 ) {
            //angle() -= _spin--;
            angle() -= _spin;
            _spin -= (deltaTime * .1);
         // When done spinning, clear the collied flag
            //if( _spin <= 0 )
                //collided() = false;
        }
    }

void drawVectors( float data[], int vert ) {
    vert *= 2;
    glBegin( GL_LINE_STRIP );
      for( int i = 0; i < vert; i+=2 ) {
          glVertex2f( data[i], data[i+1] );
      }
    glEnd();
    glBegin( GL_POINTS );
      for( int i = 0; i < vert; i+=2 ) {
          glVertex2f( data[i], data[i+1] );
      }
    glEnd();
}

    void Ship::renderObject() {
        static float shipData[]   = { -5,-5, 0,7, 5,-5, 0,-4, -5,-5 };
        static float thrustData[] = { -3,-5, 0,-9, 3,-5 };
     // Draw a simple triangular ship
        glColor4f( 0, 1, 1, g_config.lineAlpha );
        ::drawVectors( shipData, 5 );
     // If thrusting, show a little flame
        if( g_control.thrust == true ) {
            glColor4f( 1, 0, 0, g_config.lineAlpha );
            ::drawVectors( thrustData, 3 );
        }
    }

    void Ship::collidedObject( Object *object ) {
     // Ship collided, send it into a spin
        _spin = 50;
    }

void detectCollisions() {
    list<Object*>::iterator iter1, iter2;
    Object *obj1, *obj2;
    float distance;
    bool collision = false;
 // For each object, compare distance to other objects
    for( iter1 = objects.begin(); iter1 != objects.end(); iter1++ ) {
        obj1 = (*iter1);
        for( iter2 = objects.begin(); iter2 != objects.end(); iter2++ ) {
            obj2 = (*iter2);
            if( obj2 != obj1 ) {
             // Compute using distance formula
                distance = sqrt( pow(obj1->x() - obj2->x(), 2) +
                                 pow(obj1->y() - obj2->y(), 2) );
             // If in collision range and objects are not currently in collided state
                if( distance < (obj1->radius() + obj2->radius()) ) {
                    collision = true;
                    if( obj1->collided() == false ) {
                     // Set the object's collided flag so we don't keep calling
                        obj1->collided() = true;
                     // Call the object's collidedObject event
                        obj1->collidedObject( obj2 );
                    }
                }
            }
        }
        if( collision == false )
            obj1->collided() = false;
    }
}

/*
void detectCollisions() {
    list<Object*>::iterator iter1, iter2;
    Object *obj1, *obj2;
    float distance;
 // For each object, compare distance to other objects
    for( iter1 = objects.begin(); iter1 != objects.end(); iter1++ ) {
        obj1 = (*iter1);
        for( iter2 = objects.begin(); iter2 != objects.end(); iter2++ ) {
            obj2 = (*iter2);
            if( obj2 != obj1 ) {
             // Compute using distance formula
                distance = sqrt( pow(obj1->x() - obj2->x(), 2) +
                                 pow(obj1->y() - obj2->y(), 2) );
             // If in collision range and objects are not currently in collided state
                if( distance < (obj1->radius() + obj2->radius()) ) {
                    if( obj1->collided() == false ) {
                     // Set the object's collided flag so we don't keep calling
                        obj1->collided() = true;
                     // Call the object's collidedObject event
                        obj1->collidedObject( obj2 );
                    }
                }
            }
        }
    }
}
*/
