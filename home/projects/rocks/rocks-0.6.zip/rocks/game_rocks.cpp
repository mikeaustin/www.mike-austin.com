//
// game_rocks.cpp
//

#include "game_rocks.h"
#include "engine/glutapi.h"
#include "engine/text.h"

Rocks *game;

float rnd() { return rand() / (float)RAND_MAX; }

/* class Ship *\ --------------------------------------------------------------

   Provides core functionality for objects such as movement, rotation and
   collisions

---------------------------------------------------------------------------- */

// Rotate, thrust and spin according to controls and collision
   void Ship::advanceObject() {
    // While the player is pressing left, rotate left
       if( g_control.rotateLeft == true )
           angle() += 3 * (deltaTime * .1);
    // While the player is pressing right, rotate left
       if( g_control.rotateRight == true )
           angle() -= 3 * (deltaTime * .1);
    // If they are holding down thrus, then thrust
       if( g_control.thrust == true ) {
        // Add velocity to pointed direction
           xvel() -= .01 * sin( D2R(angle()) ) * (deltaTime * .1);
           yvel() += .01 * cos( D2R(angle()) ) * (deltaTime * .1);
       }
    // If we hit something, spin a few times
       if( _spin > 0 ) {
           angle() -= _spin;
           _spin -= (deltaTime * .1);
       }
   }

// Render the Ship
   void Ship::renderObject() {
       static Vector shipData[]   = { V(-5,-5), V(0, 7), V(5,-5), V(0,-4), V(-5,-5) };
       static Vector thrustData[] = { V(-3,-5), V(0,-9)  ,  V(0,-9), V(3,-5) };
    // Draw a simple triangular ship
       setColor( Color( 0, 1, 1 ) );
       game->drawLineStrip( shipData, 5 );
    // If thrusting, show a little flame
       if( g_control.thrust == true ) {
           setColor( Color( 1, 0, 0 ) );
           game->drawLines( thrustData, 4 );
       }
   }

// If ship collided, send it into a spin
   void Ship::collidedObject( Object *object ) {
   cout << "ship collided" << endl;
    // Spin 50 times with respect to delta time
       if( object->type() == "Rock" ) {
           game->score() += 1;
       }
       _spin = 50;
       game->lives() -= 1;
       if( game->lives() == 0 ) {
           game->mode() = &game->demoMode; // enter/exit mode methods?
           game->objects().empty();
           game->initRocks( 5 );
           delete game->ship();
       }
   }

/* class Rock *\_______________________________________________________________

   Provides core functionality for objects such as movement, rotation and
   collisions
____________________________________________________________________________
                                                                            \*/
// Calculate vertexes for pentagon 'rock'                                                                            \*/
   void Rock::initShape() {
       int i = 0;
       for( int a = 0; a <= 360; a += (360/5) ) {
           _rockData[i].x() = cos(D2R(a)) * radius();
           _rockData[i].y() = sin(D2R(a)) * radius();
           i += 1;
       }
   }

// Render the rock
   void Rock::renderObject() {
    // Draw a hexagon for a simple rock
       setColor( Color( 1, 1, 0 ) );
       if( this == game->rock )
           setColor( Color( 1, 0, 1 ) );
       game->drawLineStrip( _rockData, 6 );
   }

// If rock collided, divide radius by 2
// If radius < 3, dispose of rock
   void Rock::collidedObject( Object *object ) {
    // If hit another rock, don't do anything
//       if( this == game->rock )
//           cout << "original rock hit: " << type() << endl;
           
       if( object->type() == "Rock" ) {
           return;
       }
       radius() /= 2;
    // If the radius < 2, dispose of it
       if( radius() < 2 ) {
           dispose() = true;
           return;
       }
       spinvel() = -spinvel();
       initShape();

    // Create a new rock fragment
       Rock *rock = new Rock( this );
        rock->x() += xvel() < 0 ? radius() : -radius();
        rock->xvel() += rnd() * .1 -.05;
        rock->yvel() += rnd() * .1 -.05;
       xvel() += rnd() * .1 -.05;
       yvel() += rnd() * .1 -.05;
       game->objects().append( rock );  //adding now will invalidate stl iterator
       x() += xvel() > 0 ? radius() : -radius();
   }

/* class Laser *\______________________________________________________________

   Provides core functionality for objects such as movement, rotation and
   collisions
____________________________________________________________________________
                                                                            \*/
// Calculate the laser's remaining life
   void Laser::advanceObject() {
       _life -= (deltaTime * .1) * (timeWarp * .01);
       if( _life <= 0 ) {
           dispose() = true;
       }
   }

// Render the laser object
   void Laser::renderObject() {
       static Vector laserData[] = { V(-1,-1), V( 0, 1), V( 1,-1), V(-1,-1) };
       setColor( Color( 0, 1, 0 ) );
       //setAlpha( _life / 200.0 );  cuases b&w mode problems
       game->drawLineStrip( laserData, 4 );
   }

// Laser collided with some object, dispose of it
   void Laser::collidedObject( Object *object ) {
       if( object->type() == "Rock" ) {
           game->score() += 10;
       }
       dispose() = true;
   }

/* class Rocks *\______________________________________________________________

   Provides core functionality for objects such as movement, rotation and
   collisions
____________________________________________________________________________
                                                                            \*/
// The Rocks game class, derived from Game for key and timer events
   Rocks::Rocks( int argc, char* argv[] ) :
    Game( argc, argv, new GlutApi() ), _score(0), _level(1) {
       cout << "f = Fire" << endl;
       cout << "Arrow keys = Move" << endl;
       cout << "Space = TimeWarp" << endl;
       cout << "F1 = Color / B & W" << endl;
       cout << "F2 = Point Light" << endl;
       cout << "F3/F4 = Beam Flicker +/-" << endl;
       cout << "F5/F6 = Line Alpha +/-" << endl;
       cout << "F7/F8 = Line Width +/-" << endl;
       cout << "[Creating objects...]" << endl;
       initRocks( 5 );
       mode() = &demoMode;
   }

   void Rocks::newGame() {
       objects().empty();
       initRocks( level() );
       game->ship() = new Ship();
        game->ship()->x() = 50;  game->ship()->y() = 50;
        game->objects().append( game->ship() );
       game->lives() = 3;
       game->score() = 0;
       game->mode() = &game->playMode;
   }

   void Rocks::initRocks( int count ) {
       Object *rock2;
    // Create count rocks
       for( int i = 0; i < count; i++ ) {
           rock = new Rock();
            rock->x() = rnd() * 200 - 100;
            rock->y() = rnd() * 200 - 100;
            rock->xvel() = rnd() -.5;
            rock->yvel() = rnd() -.5;
            rock->spinvel() = -.5;
            objects().append( rock );
       }
   }

   void Rocks::drawScore() {
       setColor( Color( 1, 1, 1 ) );
       glTranslatef( g_config.coordsWidth -100 , g_config.coordsHeight - 30, 0 );
       drawNumber( game->score() / 1000 % 10 );
       glTranslatef( 10, 0, 0 );    drawNumber( (game->score() / 100) % 10 );
       glTranslatef( 10, 0, 0 );    drawNumber( (game->score() / 10) % 10 );
       glTranslatef( 10, 0, 0 );    drawNumber( game->score() % 10 );
       glTranslatef( 20, 8, 0 );
       for( int i = lives(); i > 0; i-- ) {
           ship()->renderObject();
           glTranslatef( 15, 0, 0 );
       }
       glLoadIdentity();
   }

   void Rocks::drawStars() {
       float x, y;
       glColor4f( 1, 1, 1, 1 );
       //setColor( Color( 1, 1, 1 ) );
       glDisable( GL_POINT_SMOOTH );
       glPointSize( 1.0 );
       glBegin( GL_POINTS );
         for( int i = 0; i < 200; i++ ) {
             x = rand() / (double)RAND_MAX;
             y = rand() / (double)RAND_MAX;
             glVertex2f( (x * g_config.coordsWidth * 2)  - g_config.coordsWidth,
                         (y * g_config.coordsHeight * 2) - g_config.coordsHeight );
         }
       glEnd();
       glEnable( GL_POINT_SMOOTH );
       glPointSize( 1.5 );
       //api()->setPointSize( 1.5 );
   }

   void Rocks::sizeChange( int width, int height ) {
       glNewList( 1, GL_COMPILE );
           drawStars();
       glEndList();
   }

// Create a laser and send it on it's way
   void Rocks::fireLaser() {
       if( g_objects == 1 ) {
           game->nextLevel();
           return;
       }
       Object *obj = new Laser();
       obj->x() = ship()->x();
       obj->y() = ship()->y();
       obj->angle() = ship()->angle();

       float xvel = sin( D2R(ship()->angle()) );
       float yvel = cos( D2R(ship()->angle()) );

       obj->xvel() -= 2 * xvel;
       obj->yvel() += 2 * yvel;

       obj->x() -= xvel * (ship()->radius() + 2);
       obj->y() += yvel * (ship()->radius() + 2);
       objects().append( obj );
   }

   void Rocks::drawHelp() {
       glTranslatef( -g_config.coordsWidth + 20, -g_config.coordsHeight + 20, 0 );
       glScalef( .5, .5, 0 );
       setColor( Color( 1, 1, 1 ) );
       drawString( "F:FIRE F1:COLOR/B&W F3:FLICKER+ F4:FLICKER-" );
       glLoadIdentity();
   }

/* class GameMode *\___________________________________________________________

   Provides core functionality for objects such as movement, rotation and
   collisions
____________________________________________________________________________
                                                                            \*/
// Draw score and a stary background
   void PlayMode::renderScreen() {
       game->drawScore();
       game->drawHelp();
       //drawStars();
       glCallList( 1 );
   }

// Handles keyboard down events
   void PlayMode::keyDown( int key ) {
       if( key == Game::KeyLeft )  g_control.rotateLeft  = true;
       if( key == Game::KeyRight ) g_control.rotateRight = true;
       if( key == Game::KeyUp )    g_control.thrust      = true;
       if( key == ' ' )      g_control.timeWarp    = true;
       if( key == 'a' )      degradeFps            = true;
       if( key == 'f' )      game->fireLaser();
   }

// Handles keyboard up events
   void PlayMode::keyUp( int key ) {
       if( key == Game::KeyLeft )  g_control.rotateLeft  = false;
       if( key == Game::KeyRight ) g_control.rotateRight = false;
       if( key == Game::KeyUp )    g_control.thrust      = false;
       if( key == ' ' )      g_control.timeWarp    = false;
       if( key == 'a' )      degradeFps            = false;
   }

   void Rocks::nextLevel() {
       cout << "Next Level!" << endl;
       level()++;
       initRocks( level() );
   }

// Draw score and a stary background
   void DemoMode::renderScreen() {
       glCallList( 1 );

       setColor( Color( 1, 1, 1 ) );
       glTranslatef( -67.5, 0, 0 );
       drawString( "GAME OVER" );
       glLoadIdentity();
       glTranslatef( -41.25 - 4, -20, 0 );
       glScalef( .5, .5, 0 );
       drawString( "INSERT COIN" );
       glTranslatef( -41.25 - 4, -20, 0 );
       drawString( "ABCDEFGHIJKLMNOPQRSTUVWXYZ" );
       glLoadIdentity();
   }

   void DemoMode::keyUp( int key ) {
       if( key <= 'z' )
           game->newGame();
   }

/* function Main *\___________________________________________________________

   Create a new Rocks game and enter mainLoop
____________________________________________________________________________
                                                                            \*/
   int main( int argc, char* argv[] ) {
       game = new Rocks( argc, argv );
       game->mainLoop();
   }

