#ifndef objects_h
#define objects_h

#include <iostream.h>
#include "init.h"

void drawVectors( float data[], int vert );

/* class Object *\_____________________________________________________________

  Provides core functionality for objects such as movement, rotation and
  collisions
____________________________________________________________________________
                                                                            \*/
void detectCollisions();

class Object {
 public:
    Object() : _x(0), _y(0), _angle(0),
     _xvel(0), _yvel(0), _spinvel(0),
     _collided(false), _dispose(false) { }

 // Advance the object in game time
    void advance();
 // Render the object, applying location and rotation
    void renderTransform();
 // Draws extra 2 times to draw image overlap in x and y
    void render();

    virtual void renderObject() = 0;
    virtual void advanceObject() { }
    //virtual void collidedObject( Object *object ) { collided() = false; }
    virtual void collidedObject( Object *object ) { }

    float& x() { return _x; }
    float& y() { return _y; }
    float& xvel() { return _xvel; }
    float& yvel() { return _yvel; }
    float& spinvel() { return _spinvel; }
    float& angle() { return _angle; }
    float& radius() { return _radius; }
    bool&  collided() { return _collided; }
    bool&  dispose() { return _dispose; }

 private:
    float _x, _y;
    float _angle;
    float _xvel, _yvel;
    float _spinvel;
    float _radius;
    bool  _collided;
    bool  _dispose;
};

/* class Ship *\_______________________________________________________________

  Provides core functionality for objects such as movement, rotation and
  collisions
____________________________________________________________________________
                                                                            \*/
class Ship : public Object {
 public:
    Ship() : _spin(0) { radius() = 7; }

    void advanceObject();
    void renderObject();
    void collidedObject( Object *object );

 private:
    int  _spin;
};

/* class Laser *\______________________________________________________________

  Provides core functionality for objects such as movement, rotation and
  collisions
____________________________________________________________________________
                                                                            \*/
class Laser : public Object {
 public:
    Laser() {
        radius() = 1;
        _life = 200;
    }
    void advanceObject() {
        _life -= (deltaTime * .1) * (timeWarp * .01);
        if( _life <= 0 ) {
            //objects.remove( this );
            dispose() = true;
        }
    }
    void renderObject() {
        //glColor4f( 0, 1, 1, g_config.lineAlpha / ( 1 - (_life/200) ) );
        glColor4f( 0, 1, 0, _life / 250 );
        glBegin( GL_LINE_LOOP );
          glVertex2i( -1, -1 );
          glVertex2i(  0,  1 );
          glVertex2i(  1, -1 );
        glEnd();
    }
    void collidedObject( Object *object ) {
        dispose() = true;
    }

 private:
    float _life;
};

/* class Rock *\_______________________________________________________________

  Provides core functionality for objects such as movement, rotation and
  collisions
____________________________________________________________________________
                                                                            \*/
class Rock : public Object {
 public:

    //Rock() : _radius(10) { }
    Rock() {
        radius() = 20;
        initShape();
    }
    void initShape() {
        int i = 0;
        for( int a = 0; a <= 360; a += (360/5) ) {
            _rockData[i] = cos(D2R(a)) * radius();
            _rockData[i+1] = sin(D2R(a)) * radius();
            i += 2;
        }
    }

    void renderObject() {
     // Draw a hexagon for a simple rock
        glColor4f( 1, 1, 0, g_config.lineAlpha );
        ::drawVectors( _rockData, 6 );
    }

    void collidedObject( Object *object ) {
        //cout << "collided rock" << endl;
        spinvel() = -spinvel();
        radius() /= 2;
        cout << endl << radius() << endl;
        if( radius() < 3 ) {
            dispose() == true;
            return;
        } else {
            initShape();
            Object *rock = new Rock();
//            temp_objects.push_back( rock );  //adding now will invalidate iterator!
            // how to insert node while iterating?
            //collided() = false;
        }
    }

 private:
    float _rockData[6*2];
    //int _radius;
};

#endif
