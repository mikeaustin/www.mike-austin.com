This screensaver is a simple n-body simulation.  I was playing around with simple gravity simulations and I though it would look nice as a screensaver.  Each particle is attracted to every other particle, and colors are based on mass and velocity.  It is less than 400 lines of code.

Some things you can do while active:

- Click and Drag to rotate the view
- Press 'b' to show a 3D box
- Press <space> to stop/start the simulation
- Press 'r' to restart the simulation
- Press 'f' to enable/disable fog

Mike Austin
http://www.mike-austin.com
